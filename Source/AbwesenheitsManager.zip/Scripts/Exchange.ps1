param([Parameter(Mandatory)][string]$RequestPath,[Parameter(Mandatory)][string]$ResponsePath)
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$connected=$false
try {
    $r=Get-Content -LiteralPath $RequestPath -Raw | ConvertFrom-Json
    if($r.Mode -notin @('Read','Apply','Test')) { throw 'Unbekannter Modus.' }
    Import-Module ExchangeOnlineManagement -MinimumVersion 3.7.0 -ErrorAction Stop
    $thumb=$r.Thumbprint -replace '\s',''
    if($thumb -notmatch '^[A-Fa-f0-9]{40}$') { throw 'Ungültiger Thumbprint.' }
    $cert=Get-Item -LiteralPath "Cert:\LocalMachine\My\$thumb"
    if(!$cert.HasPrivateKey -or $cert.NotAfter -le (Get-Date) -or $cert.NotBefore -gt (Get-Date)) { throw 'Zertifikat nicht nutzbar.' }
    Connect-ExchangeOnline -AppId $r.AppId -Organization $r.Tenant -Certificate $cert -ShowBanner:$false -ErrorAction Stop | Out-Null
    $connected=$true
    switch($r.Mode) {
        'Test' {
            Get-Command Get-EXOMailbox,Get-MailboxAutoReplyConfiguration,Set-MailboxAutoReplyConfiguration -ErrorAction Stop | Out-Null
            $probe=Get-EXOMailbox -ResultSize 1 -ErrorAction Stop
            if($probe) { Get-MailboxAutoReplyConfiguration -Identity $probe.PrimarySmtpAddress -ErrorAction Stop | Out-Null }
            $result=@{ Message='Verbindung und Lesezugriff erfolgreich; erforderliche Cmdlets vorhanden. Schreibrechte erst im Pilotlauf verifizieren.' }
        }
        'Read' {
            $boxes=[Collections.Generic.List[object]]::new()
            $errors=[Collections.Generic.List[string]]::new()
            $mailboxes=Get-EXOMailbox -ResultSize Unlimited -RecipientTypeDetails UserMailbox,SharedMailbox -ErrorAction Stop
            foreach($mailbox in $mailboxes) {
                $id=[string]$mailbox.PrimarySmtpAddress
                if($r.ExcludedMailboxes -contains $id) { $boxes.Add(@{Identity=$id;State='Excluded';InternalHtml='';ExternalHtml=''}); continue }
                try {
                    $a=Get-MailboxAutoReplyConfiguration -Identity $id -ErrorAction Stop
                    $boxes.Add(@{Identity=$id;State=[string]$a.AutoReplyState;InternalHtml=[string]$a.InternalMessage;ExternalHtml=[string]$a.ExternalMessage})
                } catch { $errors.Add("${id}: $($_.Exception.Message)") }
            }
            $result=@{Mailboxes=@($boxes.ToArray());Errors=@($errors.ToArray())}
        }
        'Apply' {
            . (Join-Path $PSScriptRoot 'Apply-Changes.ps1')
            $result=@(Invoke-GuardedChanges -Changes $r.Changes -ExcludedMailboxes $r.ExcludedMailboxes)
        }
    }
    ConvertTo-Json -InputObject $result -Depth 20 | Set-Content -LiteralPath $ResponsePath -Encoding utf8
} catch { [Console]::Error.WriteLine($_.Exception.Message); exit 1 }
finally { if($connected) { Disconnect-ExchangeOnline -Confirm:$false -ErrorAction SilentlyContinue | Out-Null } }
