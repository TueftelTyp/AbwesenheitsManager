param([Parameter(Mandatory)][string]$RequestPath,[Parameter(Mandatory)][string]$ResponsePath)
$ErrorActionPreference='Stop'
try {
    $r=Get-Content -LiteralPath $RequestPath -Raw | ConvertFrom-Json
    if($r.Mode -eq 'Create') {
        $cert=New-SelfSignedCertificate -Subject 'CN=AbwesenheitsManager' -CertStoreLocation 'Cert:\LocalMachine\My' -Provider 'Microsoft Enhanced RSA and AES Cryptographic Provider' -KeySpec Signature -KeyLength 2048 -HashAlgorithm SHA256 -KeyExportPolicy NonExportable -NotAfter (Get-Date).AddYears(1)
    } elseif($r.Mode -eq 'Inspect') {
        $thumb=$r.Thumbprint -replace '\s',''
        if($thumb -notmatch '^[A-Fa-f0-9]{40}$') { throw 'Ungültiger Thumbprint.' }
        $cert=Get-Item -LiteralPath "Cert:\LocalMachine\My\$thumb"
        if($cert.HasPrivateKey) {
            $key=[Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($cert)
            try { $null=$key.SignData([byte[]](1,2,3),[Security.Cryptography.HashAlgorithmName]::SHA256,[Security.Cryptography.RSASignaturePadding]::Pkcs1) }
            finally { if($key) { $key.Dispose() } }
        }
    } else { throw 'Unbekannter Zertifikatmodus.' }
    @{Thumbprint=$cert.Thumbprint;Subject=$cert.Subject;NotBefore=$cert.NotBefore;NotAfter=$cert.NotAfter;HasPrivateKey=$cert.HasPrivateKey;PublicBase64=[Convert]::ToBase64String($cert.Export([Security.Cryptography.X509Certificates.X509ContentType]::Cert))} | ConvertTo-Json | Set-Content -LiteralPath $ResponsePath -Encoding utf8
} catch { [Console]::Error.WriteLine($_.Exception.Message); exit 1 }
