$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Apply-Changes.ps1')
$script:writes=0
$script:readFails=$false
$script:writeFails=$false
$script:state='Disabled'
$script:internal='alt-intern'
$script:external='alt-extern'
function Get-MailboxAutoReplyConfiguration {
    [CmdletBinding()]param([string]$Identity)
    if($script:readFails) { throw 'Lesefehler' }
    return @{AutoReplyState=$script:state;InternalMessage=$script:internal;ExternalMessage=$script:external}
}
function Set-MailboxAutoReplyConfiguration {
    [CmdletBinding(SupportsShouldProcess)]param([string]$Identity,[string]$InternalMessage,[string]$ExternalMessage)
    if($script:writeFails) { throw 'Schreibfehler' }
    $script:writes++
    $script:lastParameters=@{}+$PSBoundParameters
}
function Assert([bool]$condition,[string]$label) { if(!$condition) { throw "FAIL: $label" }; Write-Host "PASS: $label" }
$change=[pscustomobject]@{Identity='test@example.org';OriginalInternal='alt-intern';OriginalExternal='alt-extern';InternalHtml='neu';ExternalHtml=$null}
foreach($state in @('Enabled','Scheduled','Unexpected')) {
    $script:state=$state
    $r=@(Invoke-GuardedChanges @($change) @())
    Assert ($script:writes -eq 0 -and $r[0].Outcome -eq 'Skipped') "Status $state blockiert"
}
$script:state='Disabled'
$r=@(Invoke-GuardedChanges @($change) @('TEST@example.org'))
Assert ($script:writes -eq 0 -and $r[0].Outcome -eq 'Skipped') 'Ausschluss unmittelbar vor Schreiben'
$script:internal='zwischenzeitlich geändert'
$r=@(Invoke-GuardedChanges @($change) @())
Assert ($script:writes -eq 0 -and $r[0].Outcome -eq 'Skipped') 'Gleichzeitige Textänderung blockiert'
$script:internal='alt-intern'; $script:readFails=$true
$r=@(Invoke-GuardedChanges @($change) @())
Assert ($script:writes -eq 0 -and $r[0].Outcome -eq 'Error') 'Lesefehler führt nie zu Schreibzugriff'
$script:readFails=$false; $script:writeFails=$true
$r=@(Invoke-GuardedChanges @($change) @())
Assert ($script:writes -eq 0 -and $r[0].Outcome -eq 'Error') 'Schreibfehler wird gemeldet'
$script:writeFails=$false
$r=@(Invoke-GuardedChanges @($change) @())
Assert ($script:writes -eq 1 -and $r[0].Outcome -eq 'Changed') 'Deaktivierte unveränderte Nachricht korrigiert'
Assert (!$script:lastParameters.ContainsKey('ExternalMessage')) 'Gültige externe Seite bleibt unberührt'
Assert (!$script:lastParameters.ContainsKey('AutoReplyState')) 'Status wird nicht gesetzt'
Write-Host '10 Schutztests erfolgreich; keine Verbindung zu Exchange hergestellt.'
