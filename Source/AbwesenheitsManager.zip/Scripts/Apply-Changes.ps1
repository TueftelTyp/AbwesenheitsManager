function Invoke-GuardedChanges {
    param([object[]]$Changes,[string[]]$ExcludedMailboxes)
    $results=[Collections.Generic.List[object]]::new()
    foreach($change in $Changes) {
        $id=[string]$change.Identity
        try {
            if($ExcludedMailboxes -contains $id) { $results.Add(@{Identity=$id;Outcome='Skipped';Detail='Ausgeschlossen'}); continue }
            $a=Get-MailboxAutoReplyConfiguration -Identity $id -ErrorAction Stop
            if([string]$a.AutoReplyState -cne 'Disabled' -or [string]$a.InternalMessage -cne [string]$change.OriginalInternal -or [string]$a.ExternalMessage -cne [string]$change.OriginalExternal) {
                $results.Add(@{Identity=$id;Outcome='Skipped';Detail='Status oder Texte seit Prüfung geändert'}); continue
            }
            $parameters=@{Identity=$id;ErrorAction='Stop';Confirm=$false}
            if($null -ne $change.InternalHtml) { $parameters.InternalMessage=[string]$change.InternalHtml }
            if($null -ne $change.ExternalHtml) { $parameters.ExternalMessage=[string]$change.ExternalHtml }
            if($parameters.ContainsKey('InternalMessage') -or $parameters.ContainsKey('ExternalMessage')) {
                # Status, Zeitplan und ExternalAudience werden niemals gesetzt.
                Set-MailboxAutoReplyConfiguration @parameters
                $results.Add(@{Identity=$id;Outcome='Changed';Detail='Abweichende Texte korrigiert'})
            }
        } catch { $results.Add(@{Identity=$id;Outcome='Error';Detail=$_.Exception.Message}) }
    }
    return $results.ToArray()
}
