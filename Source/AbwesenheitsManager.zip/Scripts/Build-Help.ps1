#Requires -Version 7.0
param()
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$readme=Join-Path $root 'README.md'
$destination=Join-Path $root 'AbwesenheitsManager.Admin\Help\Handbuch.html'
$html=(ConvertFrom-Markdown -LiteralPath $readme).Html
# Lokale Markdown-Verweise auch aus dem kopierten Hilfeordner nutzbar machen.
# README verwendet derzeit ausschließlich externe Links und Inline-Dateinamen.
$headings=[Collections.Generic.List[string]]::new()
$script:headingIndex=0
$html=[regex]::Replace($html,'<h2(?:\s[^>]*)?>(.*?)</h2>',[Text.RegularExpressions.MatchEvaluator]{
    param($match)
    $script:headingIndex++
    $id='kapitel-'+$script:headingIndex
    $label=[regex]::Replace($match.Groups[1].Value,'<[^>]+>','')
    $headings.Add('<li><a href="#'+$id+'">'+$label+'</a></li>')
    return '<h2 id="'+$id+'">'+$match.Groups[1].Value+'</h2>'
})
$toc=($headings -join "`n")
$document=@"
<!doctype html>
<html lang="de">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src data:; base-uri 'none'; form-action 'none'">
<title>AbwesenheitsManager – Handbuch</title>
<style>
:root{color-scheme:light;font-family:Segoe UI,Arial,sans-serif;color:#17243b;background:#f1f5f9;line-height:1.65}
*{box-sizing:border-box}body{margin:0}header{background:#0f172a;color:white;padding:30px max(24px,calc((100vw - 1200px)/2))}header strong{font-size:26px}header p{margin:4px 0;color:#bfdbfe}
.layout{display:grid;grid-template-columns:260px minmax(0,1fr);gap:32px;max-width:1248px;margin:32px auto;padding:0 24px}
nav{position:sticky;top:24px;align-self:start;font-size:14px}nav ul{list-style:none;padding:0}nav li{margin:8px 0}nav a{text-decoration:none}
main{min-width:0;background:white;border:1px solid #e2e8f0;border-radius:12px;padding:32px 40px}h1{font-size:32px;margin-top:0}h2{font-size:24px;border-top:1px solid #e2e8f0;margin-top:40px;padding-top:24px;scroll-margin-top:20px}h3{font-size:19px}a{color:#1d4ed8;overflow-wrap:anywhere}a:hover{text-decoration:underline}a:focus-visible{outline:3px solid #2563eb;outline-offset:3px}p,li{overflow-wrap:anywhere}
pre{background:#0f172a;color:#e2e8f0;padding:18px;border-radius:8px;overflow:auto;line-height:1.5}code{font-family:Consolas,monospace;font-size:.92em}p code,li code{background:#eef2ff;padding:2px 4px;border-radius:3px}
table{display:block;overflow:auto;border-collapse:collapse;width:100%;font-size:14px}th,td{border:1px solid #cbd5e1;padding:10px;text-align:left}th{background:#eff6ff}blockquote{border-left:4px solid #60a5fa;margin-left:0;padding:4px 20px;background:#f8fafc}footer{color:#64748b;font-size:13px;margin-top:32px}.skip{position:absolute;left:-10000px}.skip:focus{left:16px;top:10px;background:white;padding:8px}
@media(max-width:850px){.layout{grid-template-columns:1fr;margin:20px auto;gap:16px}nav{position:static}main{padding:24px}header{padding:24px}}
@media print{header,nav,.skip,footer{display:none}.layout{display:block;margin:0;padding:0}main{border:0;padding:0}pre{white-space:pre-wrap;color:black;background:#f1f5f9}h2{break-after:avoid}a{color:inherit}}
</style>
</head>
<body>
<a class="skip" href="#handbuch">Zum Handbuch</a>
<header><strong>AbwesenheitsManager</strong><p>Handbuch · .NET 9 · Windows</p></header>
<div class="layout"><nav aria-label="Inhaltsverzeichnis"><strong>Inhalt</strong><ul>$toc</ul><p>Suche: Strg+F<br>Drucken: Strg+P</p><p>Das Handbuch ist offline lesbar. Externe Verweise benötigen Internet.</p></nav>
<main id="handbuch">$html<footer>Aus README.md erzeugt. Öffnen in der Anwendung: Fragezeichen oben rechts oder F1.</footer></main></div>
</body></html>
"@
New-Item -ItemType Directory -Path (Split-Path $destination -Parent) -Force | Out-Null
[IO.File]::WriteAllText($destination,$document,[Text.UTF8Encoding]::new($false))
Write-Host "Handbuch erzeugt: $destination"
