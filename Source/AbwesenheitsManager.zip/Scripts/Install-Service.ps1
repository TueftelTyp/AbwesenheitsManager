#Requires -RunAsAdministrator
param([Parameter(Mandatory)][string]$ServiceDirectory)
$ErrorActionPreference='Stop'
$directory=(Resolve-Path -LiteralPath $ServiceDirectory).Path
$exe=Join-Path $directory 'AbwesenheitsManager.Service.exe'
if(!(Test-Path -LiteralPath $exe -PathType Leaf)) { throw "Service-EXE fehlt: $exe" }
if(Get-Service AbwesenheitsManager -ErrorAction SilentlyContinue) { throw 'Dienst existiert bereits. Für Update stoppen, Dateien ersetzen und wieder starten.' }
if($directory.StartsWith('\\')) { throw 'Dienst muss auf einem lokalen Laufwerk liegen.' }
if($directory.TrimEnd('\') -eq [IO.Path]::GetPathRoot($directory).TrimEnd('\')) { throw 'Kein Laufwerksstamm als Serviceverzeichnis zulässig.' }
if((Get-Item -LiteralPath $directory).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Kein verknüpftes Serviceverzeichnis zulässig.' }
if(Get-ChildItem -LiteralPath $directory -Recurse -Force | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }) { throw 'Serviceverzeichnis enthält Verknüpfungen. Abbruch vor ACL-Änderung.' }
# Binärdateien dürfen nur Administratoren und SYSTEM ändern.
function Protect-Directory([string]$Path) {
    $acl=[Security.AccessControl.DirectorySecurity]::new()
    $acl.SetAccessRuleProtection($true,$false)
    foreach($sid in @('S-1-5-18','S-1-5-32-544')) {
        $identity=[Security.Principal.SecurityIdentifier]::new($sid)
        $acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($identity,'FullControl','ContainerInherit, ObjectInherit','None','Allow'))
    }
    Set-Acl -LiteralPath $Path -AclObject $acl
    foreach($item in Get-ChildItem -LiteralPath $Path -Recurse -Force) {
        $childAcl=Get-Acl -LiteralPath $item.FullName
        $childAcl.SetAccessRuleProtection($false,$false)
        foreach($rule in @($childAcl.Access | Where-Object { !$_.IsInherited })) { $null=$childAcl.RemoveAccessRuleSpecific($rule) }
        Set-Acl -LiteralPath $item.FullName -AclObject $childAcl
    }
}
Protect-Directory $directory
$data=Join-Path $env:ProgramData 'AbwesenheitsManager'
New-Item -ItemType Directory -Force -Path $data | Out-Null
if((Get-Item -LiteralPath $data).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Verknüpftes Datenverzeichnis nicht zulässig.' }
if(Get-ChildItem -LiteralPath $data -Recurse -Force | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }) { throw 'Datenverzeichnis enthält Verknüpfungen.' }
Protect-Directory $data
New-Service -Name AbwesenheitsManager -DisplayName 'AbwesenheitsManager' -BinaryPathName ('"'+$exe+'"') -StartupType Automatic -Description 'Prüft deaktivierte Exchange-Online-Abwesenheitsvorlagen.' | Out-Null
& sc.exe failure AbwesenheitsManager reset= 86400 actions= restart/60000/restart/120000/restart/300000
if($LASTEXITCODE -ne 0) { throw 'Wiederherstellungsoptionen konnten nicht gesetzt werden.' }
Write-Host 'Installiert als LocalSystem, noch nicht gestartet. Erst GUI konfigurieren und Dry-Run prüfen; dann Start-Service AbwesenheitsManager.'
