param([string]$OutputPath=(Join-Path $PSScriptRoot '..\publish'))
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
& (Join-Path $PSScriptRoot 'Build-Help.ps1')
foreach($name in @('Admin','Service')) {
    & dotnet publish (Join-Path $root "AbwesenheitsManager.$name\AbwesenheitsManager.$name.csproj") -c Release -r win-x64 --self-contained true -o (Join-Path $OutputPath $name)
    if($LASTEXITCODE -ne 0) { throw "Publish für $name fehlgeschlagen." }
}
