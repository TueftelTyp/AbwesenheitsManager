#Requires -RunAsAdministrator
$ErrorActionPreference='Stop'
$service=Get-Service AbwesenheitsManager -ErrorAction SilentlyContinue
if($service) {
    Stop-Service AbwesenheitsManager -ErrorAction Stop
    $service.WaitForStatus('Stopped',[TimeSpan]::FromSeconds(90))
    & sc.exe delete AbwesenheitsManager
    if($LASTEXITCODE -ne 0) { throw 'Dienst konnte nicht entfernt werden.' }
}
Write-Host 'Dienst entfernt. Konfiguration, Logs und Zertifikate bleiben erhalten.'
