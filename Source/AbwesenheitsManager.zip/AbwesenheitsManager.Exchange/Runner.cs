using AbwesenheitsManager.Core;
namespace AbwesenheitsManager.Exchange;
public sealed class Runner
{
    public async Task<RunSummary> Run(Settings s,bool forceDryRun,CancellationToken token)
    {
        // FileShare.None serialisiert Dienst und GUI auf diesem Computer, auch über await hinweg.
        using var runLock=new FileStream(Path.Combine(Storage.Root,"run.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);
        var summary=new RunSummary { DryRun=s.DryRun || forceDryRun };
        try
        {
            Templates.Validate(s);
            if(!Guid.TryParse(s.AppId,out _) || string.IsNullOrWhiteSpace(s.Tenant)) throw new ArgumentException("Tenant/App-ID fehlen oder sind ungültig.");
            var cert=await PowerShell.Certificate(s,"Inspect",token);
            if(!cert.HasPrivateKey || cert.NotBefore.ToUniversalTime()>DateTime.UtcNow || cert.NotAfter.ToUniversalTime()<=DateTime.UtcNow) throw new InvalidOperationException("Zertifikat ist ungültig oder ohne privaten Schlüssel.");
            if(cert.NotAfter.ToUniversalTime()<=DateTime.UtcNow.AddDays(s.CertificateWarningDays)) summary.Warnings.Add($"Zertifikat läuft am {cert.NotAfter:O} ab.");
            var snapshot=await PowerShell.Exchange<Snapshot>(s,"Read",[],token); summary.Errors.AddRange(snapshot.Errors);
            var changes=new List<Change>();
            foreach(var box in snapshot.Mailboxes)
            {
                summary.Checked++;
                if(box.State!="Disabled" || s.ExcludedMailboxes.Contains(box.Identity,StringComparer.OrdinalIgnoreCase)) { summary.Skipped++; continue; }
                try
                {
                    var change=Templates.Plan(box,s);
                    if(change is null) summary.Valid++;
                    else { changes.Add(change); summary.Results.Add(new(box.Identity,"Planned","Abweichende Seite wird durch Standardvorlage ersetzt.")); }
                }
                catch(Exception ex) { summary.Errors.Add(box.Identity+": "+ex.Message); }
            }
            summary.WouldChange=changes.Count;
            if(changes.Count>0) summary.Warnings.Add($"{changes.Count} Postfächer mit Vorlagenabweichungen gefunden.");
            if(!summary.DryRun && changes.Count>0)
            {
                var results=await PowerShell.Exchange<List<ApplyResult>>(s,"Apply",changes.Cast<object>().ToArray(),token);
                summary.Results=results;
                summary.Changed=results.Count(r=>r.Outcome=="Changed");
                foreach(var r in results.Where(r=>r.Outcome=="Error")) summary.Errors.Add(r.Identity+": "+r.Detail);
                foreach(var r in results.Where(r=>r.Outcome=="Skipped")) { summary.Skipped++; summary.Warnings.Add(r.Identity+": "+r.Detail); }
            }
        }
        catch(OperationCanceledException) { summary.Errors.Add("Lauf abgebrochen oder Zeitlimit erreicht. Bei unterbrochenem Schreibvorgang ist der Änderungsstand möglicherweise unvollständig; erneut im Dry-Run prüfen."); }
        catch(Exception ex) { summary.Errors.Add(ex.Message); }
        summary.Finished=DateTimeOffset.Now;
        try
        {
            using var smtpTimeout=new CancellationTokenSource(TimeSpan.FromSeconds(30));
            await SmtpNotifier.Notify(s,summary,smtpTimeout.Token);
        }
        catch(Exception ex) { summary.Errors.Add("SMTP-Sammelmeldung fehlgeschlagen: "+ex.Message); }
        Storage.Save("last-run.json",summary);
        foreach(var warning in summary.Warnings) Storage.Log(s,LogLevel.Warning,warning);
        foreach(var error in summary.Errors) Storage.Log(s,LogLevel.Error,error);
        Storage.Log(s,LogLevel.Information,$"Lauf beendet: geprüft={summary.Checked}, geändert={summary.Changed}, DryRun={summary.DryRun}");
        Storage.Log(s,LogLevel.Debug,System.Text.Json.JsonSerializer.Serialize(summary,Storage.Json));
        return summary;
    }
}
