using System.Diagnostics;
using System.Text;
using System.Text.Json;
using AbwesenheitsManager.Core;
namespace AbwesenheitsManager.Exchange;
public static class PowerShell
{
    public static async Task<T> Execute<T>(Settings settings,string script,object request,CancellationToken token)
    {
        var folder=Path.Combine(Storage.Root,"Jobs",Guid.NewGuid().ToString("N")); Directory.CreateDirectory(folder);
        var input=Path.Combine(folder,"request.json"); var output=Path.Combine(folder,"response.json");
        try
        {
            await File.WriteAllTextAsync(input,JsonSerializer.Serialize(request,Storage.Json),new UTF8Encoding(false),token);
            var start=new ProcessStartInfo(settings.PowerShellPath) { UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true };
            foreach(var arg in new[]{"-NoLogo","-NoProfile","-NonInteractive","-File",Path.Combine(AppContext.BaseDirectory,"Scripts",script),"-RequestPath",input,"-ResponsePath",output}) start.ArgumentList.Add(arg);
            using var process=Process.Start(start) ?? throw new IOException("PowerShell konnte nicht gestartet werden.");
            var stdout=process.StandardOutput.ReadToEndAsync(token); var stderr=process.StandardError.ReadToEndAsync(token);
            using var timeout=CancellationTokenSource.CreateLinkedTokenSource(token); timeout.CancelAfter(TimeSpan.FromMinutes(settings.TimeoutMinutes));
            try { await process.WaitForExitAsync(timeout.Token); }
            catch { if(!process.HasExited) process.Kill(true); await process.WaitForExitAsync(CancellationToken.None); throw; }
            _=await stdout; var error=await stderr;
            if(process.ExitCode!=0) throw new InvalidOperationException($"PowerShell fehlgeschlagen ({process.ExitCode}): {error}");
            return JsonSerializer.Deserialize<T>(await File.ReadAllTextAsync(output,token),Storage.Json) ?? throw new InvalidDataException("PowerShell lieferte kein Ergebnis.");
        }
        finally { if(Directory.Exists(folder)) Directory.Delete(folder,true); }
    }
    public static Task<T> Exchange<T>(Settings s,string mode,object[] changes,CancellationToken ct) => Execute<T>(s,"Exchange.ps1",new { Mode=mode,s.Tenant,s.AppId,s.Thumbprint,s.ExcludedMailboxes,Changes=changes },ct);
    public static Task<CertificateInfo> Certificate(Settings s,string mode,CancellationToken ct) => Execute<CertificateInfo>(s,"Certificate.ps1",new { Mode=mode,s.Thumbprint },ct);
}
public sealed record CertificateInfo(string Thumbprint,string Subject,DateTime NotBefore,DateTime NotAfter,bool HasPrivateKey,string PublicBase64);
public sealed class Snapshot
{
    public List<Mailbox> Mailboxes { get; set; } = [];
    public List<string> Errors { get; set; } = [];
}
