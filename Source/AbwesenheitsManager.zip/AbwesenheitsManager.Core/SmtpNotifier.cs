using System.Net;
using System.Net.Mail;
using System.Text.Json;
namespace AbwesenheitsManager.Core;
public static class SmtpNotifier
{
    public static async Task Send(SmtpSettings s,string body,CancellationToken token)
    {
        using var mail=new MailMessage(s.From,s.Recipient,s.Subject,body);
        using var client=new SmtpClient(s.Host,s.Port) { EnableSsl=s.StartTls, UseDefaultCredentials=false };
        if(!string.IsNullOrWhiteSpace(s.Username)) client.Credentials=new NetworkCredential(s.Username,Storage.Unprotect(s.ProtectedPassword));
        await client.SendMailAsync(mail,token);
    }
    public static async Task Notify(Settings s,RunSummary run,CancellationToken token)
    {
        if(s.Smtp.Enabled && ((s.Smtp.OnWarnings && run.Warnings.Count>0) || (s.Smtp.OnErrors && run.Errors.Count>0)))
            await Send(s.Smtp,s.Smtp.Introduction+Environment.NewLine+JsonSerializer.Serialize(run,Storage.Json),token);
    }
}
