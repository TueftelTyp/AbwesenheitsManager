namespace AbwesenheitsManager.Core;

public enum LogLevel { Off, Error, Warning, Information, Debug }
public sealed class Variable
{
    public string Name { get; set; } = "";
    public string Placeholder { get; set; } = "";
    public string Description { get; set; } = "";
    public string ValidationPattern { get; set; } = "";
}
public sealed class Settings
{
    public string Tenant { get; set; } = "";
    public string AppId { get; set; } = "";
    public string Thumbprint { get; set; } = "";
    public string PowerShellPath { get; set; } = @"C:\Program Files\PowerShell\7\pwsh.exe";
    public bool DryRun { get; set; } = true;
    public bool SchedulerEnabled { get; set; } = false;
    public int IntervalMinutes { get; set; } = 1440;
    public int TimeoutMinutes { get; set; } = 60;
    public int CertificateWarningDays { get; set; } = 30;
    public LogLevel LogLevel { get; set; } = LogLevel.Warning;
    public string InternalHtml { get; set; } = Example;
    public string ExternalHtml { get; set; } = Example;
    public List<string> ExcludedMailboxes { get; set; } = [];
    public List<Variable> Variables { get; set; } = [
        new() { Name="Datum", Placeholder="[Datum]", Description="Letzter Urlaubstag" },
        new() { Name="Vertretung", Placeholder="[Vertretung]", Description="Name der Vertretung" },
        new() { Name="E-Mail-Adresse", Placeholder="[E-Mail-Adresse]", Description="E-Mail der Vertretung", ValidationPattern=@"[^@\s]+@[^@\s]+\.[^@\s]+" },
        new() { Name="Telefonnummer", Placeholder="[Telefonnummer]", Description="Telefon der Vertretung" }
    ];
    public SmtpSettings Smtp { get; set; } = new();
    public const string Example = """
        <html><body>
        <p>Vielen Dank für Ihre Nachricht.</p>
        <p>Ich befinde mich derzeit im Urlaub und bin bis einschließlich <b>[Datum]</b> nicht erreichbar. Ihre E-Mail wird nicht weitergeleitet und nach meiner Rückkehr schnellstmöglich bearbeitet.</p>
        <p>In dringenden Fällen wenden Sie sich bitte an <b>[Vertretung]</b> unter <b>[E-Mail-Adresse]</b> oder <b>[Telefonnummer]</b>.</p>
        <p>Vielen Dank für Ihr Verständnis.</p>
        <p>Mit freundlichen Grüßen</p>
        </body></html>
        """;
}
public sealed class SmtpSettings
{
    public bool Enabled { get; set; }
    public string Host { get; set; } = "";
    public int Port { get; set; } = 587;
    public bool StartTls { get; set; } = true;
    public string Username { get; set; } = "";
    public string ProtectedPassword { get; set; } = "";
    public string From { get; set; } = "";
    public string Recipient { get; set; } = "";
    public bool OnWarnings { get; set; } = true;
    public bool OnErrors { get; set; } = true;
    public string Subject { get; set; } = "AbwesenheitsManager – Laufmeldung";
    public string Introduction { get; set; } = "Bei der Prüfung sind folgende Meldungen aufgetreten:";
}
public sealed record Mailbox(string Identity, string State, string InternalHtml, string ExternalHtml);
public sealed record Change(string Identity, string OriginalInternal, string OriginalExternal, string? InternalHtml, string? ExternalHtml);
public sealed record ApplyResult(string Identity, string Outcome, string Detail);
public sealed class RunSummary
{
    public DateTimeOffset Started { get; set; } = DateTimeOffset.Now;
    public DateTimeOffset? Finished { get; set; }
    public bool DryRun { get; set; }
    public int Checked { get; set; }
    public int Skipped { get; set; }
    public int Valid { get; set; }
    public int WouldChange { get; set; }
    public int Changed { get; set; }
    public List<string> Warnings { get; set; } = [];
    public List<string> Errors { get; set; } = [];
    public List<ApplyResult> Results { get; set; } = [];
    public bool Success => Errors.Count == 0;
}
