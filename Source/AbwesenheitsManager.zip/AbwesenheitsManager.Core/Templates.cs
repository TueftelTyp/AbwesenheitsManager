using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using HtmlAgilityPack;

namespace AbwesenheitsManager.Core;
public static class Templates
{
    private static readonly TimeSpan Limit = TimeSpan.FromMilliseconds(250);
    public static string Canonical(string html)
    {
        var doc=new HtmlDocument(); doc.LoadHtml(html.Replace("\r\n","\n"));
        string Visit(HtmlNode node)
        {
            if(node.NodeType==HtmlNodeType.Comment) return "";
            if(node.NodeType==HtmlNodeType.Text) return WebUtility.HtmlEncode(HtmlEntity.DeEntitize(node.InnerText)).Replace("\r\n","\n");
            if(node.Name=="head") return "";
            var children=string.Concat(node.ChildNodes.Select(Visit));
            if(node.NodeType==HtmlNodeType.Document || node.Name is "html" or "body") return children.Trim();
            var attrs=string.Concat(node.Attributes.OrderBy(a=>a.Name,StringComparer.Ordinal).Select(a=>$" {a.Name.ToLowerInvariant()}=\"{WebUtility.HtmlEncode(HtmlEntity.DeEntitize(a.Value))}\""));
            return $"<{node.Name.ToLowerInvariant()}{attrs}>{children}</{node.Name.ToLowerInvariant()}>";
        }
        return Visit(doc.DocumentNode);
    }
    public static void Validate(Settings s)
    {
        if(s.IntervalMinutes<1 || s.IntervalMinutes>525600 || s.TimeoutMinutes<1 || s.TimeoutMinutes>1440 || s.CertificateWarningDays<0) throw new ArgumentException("Intervall, Timeout oder Warnfrist ungültig.");
        if(s.Variables.Any(v=>string.IsNullOrWhiteSpace(v.Name) || string.IsNullOrWhiteSpace(v.Placeholder))) throw new ArgumentException("Variablen benötigen Name und Platzhalter.");
        if(s.Variables.Select(v=>v.Placeholder).Distinct(StringComparer.Ordinal).Count()!=s.Variables.Count) throw new ArgumentException("Platzhalter müssen eindeutig sein.");
        foreach(var v in s.Variables)
        {
            if(s.Variables.Any(w=>w!=v && w.Placeholder.Contains(v.Placeholder,StringComparison.Ordinal))) throw new ArgumentException("Platzhalter dürfen sich nicht überlappen.");
            if(!string.IsNullOrWhiteSpace(v.ValidationPattern)) _ = new Regex(@"\A(?:"+v.ValidationPattern+@")\z",RegexOptions.CultureInvariant,Limit);
        }
        foreach(var html in new[]{s.InternalHtml,s.ExternalHtml})
        {
            if(string.IsNullOrWhiteSpace(html)) throw new ArgumentException("Beide HTML-Vorlagen müssen gefüllt sein.");
            var doc=new HtmlDocument(); doc.LoadHtml(html);
            foreach(var v in s.Variables)
            {
                var total=Regex.Matches(html,Regex.Escape(v.Placeholder)).Count;
                var inText=doc.DocumentNode.DescendantsAndSelf().Where(n=>n.NodeType==HtmlNodeType.Text).Sum(n=>Regex.Matches(n.InnerText,Regex.Escape(v.Placeholder)).Count);
                if(total!=inText) throw new ArgumentException("Platzhalter sind nur in HTML-Textknoten erlaubt: "+v.Placeholder);
            }
            Build(html,s.Variables);
        }
        if(s.Smtp.Enabled)
        {
            if(string.IsNullOrWhiteSpace(s.Smtp.Host) || s.Smtp.Port is <1 or >65535) throw new ArgumentException("SMTP-Host/Port ungültig.");
            _=new System.Net.Mail.MailAddress(s.Smtp.From); _=new System.Net.Mail.MailAddress(s.Smtp.Recipient);
            if(!s.Smtp.StartTls && !string.IsNullOrEmpty(s.Smtp.Username)) throw new ArgumentException("SMTP-Anmeldedaten erfordern STARTTLS.");
        }
    }
    private static (Regex Pattern,List<Variable> Used) Build(string template,List<Variable> variables)
    {
        var text=Canonical(template); var used=new List<Variable>(); var pattern=new StringBuilder(@"\A"); int pos=0;
        while(pos<text.Length)
        {
            var next=variables.Select(v=>(V:v,Token:WebUtility.HtmlEncode(v.Placeholder),Index:text.IndexOf(WebUtility.HtmlEncode(v.Placeholder),pos,StringComparison.Ordinal))).Where(x=>x.Index>=0).OrderBy(x=>x.Index).FirstOrDefault();
            if(next.V is null) { pattern.Append(Regex.Escape(text[pos..])); break; }
            pattern.Append(Regex.Escape(text[pos..next.Index]));
            if(used.Contains(next.V)) pattern.Append($"\\k<v{used.IndexOf(next.V)}>");
            else { pattern.Append($"(?<v{used.Count}>[^<>]*?)"); used.Add(next.V); }
            pos=next.Index+next.Token.Length;
            if(variables.Any(v=>text.AsSpan(pos).StartsWith(WebUtility.HtmlEncode(v.Placeholder),StringComparison.Ordinal))) throw new ArgumentException("Benachbarte Platzhalter benötigen festen Trenntext.");
        }
        pattern.Append(@"\z"); return (new Regex(pattern.ToString(),RegexOptions.CultureInvariant,Limit),used);
    }
    public static bool Matches(string current,string template,List<Variable> variables)
    {
        var (regex,used)=Build(template,variables); var match=regex.Match(Canonical(current)); if(!match.Success) return false;
        for(int i=0;i<used.Count;i++)
        {
            var value=WebUtility.HtmlDecode(match.Groups[$"v{i}"].Value);
            if(value==used[i].Placeholder) continue; // Ungefüllte Standardvorlage ist zulässig.
            if(!string.IsNullOrWhiteSpace(used[i].ValidationPattern) && !Regex.IsMatch(value,@"\A(?:"+used[i].ValidationPattern+@")\z",RegexOptions.CultureInvariant,Limit)) return false;
        }
        return true;
    }
    public static Change? Plan(Mailbox box,Settings s)
    {
        if(box.State!="Disabled" || s.ExcludedMailboxes.Contains(box.Identity,StringComparer.OrdinalIgnoreCase)) return null;
        var internalOk=Matches(box.InternalHtml,s.InternalHtml,s.Variables); var externalOk=Matches(box.ExternalHtml,s.ExternalHtml,s.Variables);
        return internalOk && externalOk ? null : new(box.Identity,box.InternalHtml,box.ExternalHtml,internalOk?null:s.InternalHtml,externalOk?null:s.ExternalHtml);
    }
}
