using System.Security.AccessControl;
using System.Security.Principal;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace AbwesenheitsManager.Core;
public static class Storage
{
    public static string Root => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "AbwesenheitsManager");
    public static JsonSerializerOptions Json { get; } = new() { WriteIndented=true, PropertyNameCaseInsensitive=true, Converters={new JsonStringEnumConverter()} };
    public static void Initialize()
    {
        var dir = Directory.CreateDirectory(Root);
        var acl = new DirectorySecurity();
        acl.SetAccessRuleProtection(true, false);
        foreach (var sid in new[] { WellKnownSidType.BuiltinAdministratorsSid, WellKnownSidType.LocalSystemSid })
            acl.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(sid,null), FileSystemRights.FullControl,
                InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow));
        dir.SetAccessControl(acl);
    }
    public static Settings Load() => File.Exists(Path.Combine(Root,"settings.json")) ? Read<Settings>("settings.json") : new();
    public static T Read<T>(string file) => JsonSerializer.Deserialize<T>(File.ReadAllText(Path.Combine(Root,file)),Json) ?? throw new InvalidDataException("Leere Datei: " + file);
    public static void Save<T>(string file,T value)
    {
        var destination=Path.Combine(Root,file);
        var temp=destination+"."+Guid.NewGuid().ToString("N")+".tmp";
        try { File.WriteAllText(temp,JsonSerializer.Serialize(value,Json),Encoding.UTF8); File.Move(temp,destination,true); }
        finally { if(File.Exists(temp)) File.Delete(temp); }
    }
    public static string Protect(string value) => Convert.ToBase64String(ProtectedData.Protect(Encoding.UTF8.GetBytes(value),null,DataProtectionScope.LocalMachine));
    public static string Unprotect(string value) => string.IsNullOrEmpty(value) ? "" : Encoding.UTF8.GetString(ProtectedData.Unprotect(Convert.FromBase64String(value),null,DataProtectionScope.LocalMachine));
    public static void Log(Settings settings,LogLevel level,string text)
    {
        if(settings.LogLevel == LogLevel.Off || level > settings.LogLevel) return;
        Directory.CreateDirectory(Path.Combine(Root,"Logs"));
        File.AppendAllText(Path.Combine(Root,"Logs",$"{DateTime.Now:yyyy-MM}.log"),$"{DateTimeOffset.Now:O} [{level}] {text.Replace('\r',' ').Replace('\n',' ')}{Environment.NewLine}");
    }
}
