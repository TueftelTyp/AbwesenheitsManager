using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using AbwesenheitsManager.Core;
using AbwesenheitsManager.Exchange;
using Microsoft.Win32;

namespace AbwesenheitsManager.Admin;
public partial class MainWindow : Window
{
    private void HelpExecuted(object sender, ExecutedRoutedEventArgs e)
    {
        e.Handled = true;
        var handbook = Path.Combine(AppContext.BaseDirectory, "Help", "Handbuch.html");
        try
        {
            if (!File.Exists(handbook))
                throw new FileNotFoundException("Das Handbuch fehlt. Bitte den vollständigen Programmordner einschließlich des Ordners Help kopieren.", handbook);
            Process.Start(new ProcessStartInfo(handbook) { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, "Das Handbuch konnte nicht geöffnet werden.\n\n" + ex.Message + "\n\nDatei: " + handbook,
                "AbwesenheitsManager – Hilfe", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }
    private Settings settings=new();
    private readonly List<Action> readers=[];
    private ObservableCollection<Variable> variables=[];
    private DataGrid variableGrid=new();
    private TextBox summaryBox=new();
    private TextBlock summaryHeadline=new();
    private PasswordBox password=new();
    private CheckBox clearPassword=new();
    private readonly DispatcherTimer timer=new() { Interval=TimeSpan.FromSeconds(5) };
    public MainWindow() : this(null) { }
    public MainWindow(Settings? previewSettings)
    {
        InitializeComponent();
        try { if(previewSettings is null) Storage.Initialize(); LoadSettings(previewSettings); }
        catch(Exception ex) { MessageBox.Show(ex.Message,"Start fehlgeschlagen"); Close(); return; }
        if(previewSettings is not null) return;
        timer.Tick+=(_,_)=>RefreshSummary(); timer.Start();
        Closing+=(_,_)=>timer.Stop();
    }
    private StackPanel Page(string title,string description)
    {
        var panel=new StackPanel { Margin=new Thickness(24) };
        panel.Children.Add(new TextBlock { Text=title,FontSize=24,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,0,0,8) });
        panel.Children.Add(new TextBlock { Text=description,TextWrapping=TextWrapping.Wrap,Foreground=Brushes.SlateGray,Margin=new Thickness(0,0,0,20) });
        Tabs.Items.Add(new TabItem { Header=title,Content=new ScrollViewer { Content=panel,VerticalScrollBarVisibility=ScrollBarVisibility.Auto } });
        return panel;
    }
    private static void Label(Panel panel,string text) => panel.Children.Add(new TextBlock { Text=text,Margin=new Thickness(0,8,0,5),FontWeight=FontWeights.SemiBold });
    private TextBox Field(Panel panel,string label,object target,string property,bool multiline=false)
    {
        Label(panel,label); var prop=target.GetType().GetProperty(property)!;
        var box=new TextBox { Text=Convert.ToString(prop.GetValue(target),System.Globalization.CultureInfo.InvariantCulture)??"",AcceptsReturn=multiline,TextWrapping=multiline?TextWrapping.Wrap:TextWrapping.NoWrap,MinHeight=multiline?140:0,VerticalScrollBarVisibility=multiline?ScrollBarVisibility.Auto:ScrollBarVisibility.Hidden };
        panel.Children.Add(box);
        readers.Add(()=> {
            object value=prop.PropertyType==typeof(int) ? int.TryParse(box.Text,out var n)?n:throw new ArgumentException(label+": Ganze Zahl erforderlich.") : box.Text;
            prop.SetValue(target,value);
        }); return box;
    }
    private CheckBox Toggle(Panel panel,string text,object target,string property)
    {
        var prop=target.GetType().GetProperty(property)!; var box=new CheckBox { Content=text,IsChecked=(bool)prop.GetValue(target)! };
        panel.Children.Add(box); readers.Add(()=>prop.SetValue(target,box.IsChecked==true)); return box;
    }
    private void ActionButton(Panel panel,string title,Func<Task> action)
    {
        var button=new Button { Content=title,HorizontalAlignment=HorizontalAlignment.Left };
        button.Click+=async(_,_)=>await Busy(action); panel.Children.Add(button);
    }
    private async Task Busy(Func<Task> action)
    {
        Tabs.IsEnabled=false; SaveButton.IsEnabled=false; ReloadButton.IsEnabled=false; Status.Text="Aktion läuft …";
        try { await action(); Status.Text="Aktion abgeschlossen."; }
        catch(Exception ex) { Status.Text="Aktion fehlgeschlagen."; MessageBox.Show(ex.Message,"AbwesenheitsManager",MessageBoxButton.OK,MessageBoxImage.Error); }
        finally { Tabs.IsEnabled=true; SaveButton.IsEnabled=true; ReloadButton.IsEnabled=true; RefreshSummary(); }
    }
    private void Collect()
    {
        variableGrid.CommitEdit(DataGridEditingUnit.Cell,true); variableGrid.CommitEdit(DataGridEditingUnit.Row,true);
        foreach(var read in readers) read(); settings.Variables=variables.ToList();
        if(clearPassword.IsChecked==true) settings.Smtp.ProtectedPassword="";
        else if(password.Password.Length>0) settings.Smtp.ProtectedPassword=Storage.Protect(password.Password);
        Templates.Validate(settings);
    }
    private void Save()
    {
        Collect(); Storage.Save("settings.json",settings); password.Clear(); clearPassword.IsChecked=false;
    }
    private void SaveClick(object sender,RoutedEventArgs e)
    {
        try { Save(); Status.Text="Gespeichert. Der Dienst übernimmt Einstellungen beim nächsten Zyklus."; }
        catch(Exception ex) { MessageBox.Show(ex.Message,"Einstellungen prüfen"); }
    }
    private void ReloadClick(object sender,RoutedEventArgs e)
    {
        try { LoadSettings(); Status.Text="Gespeicherte Einstellungen geladen."; } catch(Exception ex) { MessageBox.Show(ex.Message); }
    }
    private void LoadSettings(Settings? previewSettings=null)
    {
        settings=previewSettings ?? Storage.Load(); readers.Clear(); Tabs.Items.Clear();
        var overview=Page("Übersicht","Aktive und geplante Antworten werden übersprungen. Dry-Run prüft ohne Exchange-Schreibzugriff; konfigurierte SMTP-Meldungen können trotzdem versendet werden.");
        summaryHeadline=new TextBlock { FontSize=19,FontWeight=FontWeights.SemiBold,Margin=new Thickness(0,10,0,15),TextWrapping=TextWrapping.Wrap }; overview.Children.Add(summaryHeadline);
        var actions=new WrapPanel(); overview.Children.Add(actions);
        ActionButton(actions,"Dry-Run starten",async()=> { Save(); await new Runner().Run(settings,true,CancellationToken.None); });
        ActionButton(actions,"Lauf gemäß Einstellungen",async()=> { Save(); await new Runner().Run(settings,false,CancellationToken.None); });
        ActionButton(actions,"Exchange-Verbindung testen",async()=> { Collect(); var result=await PowerShell.Exchange<Dictionary<string,string>>(settings,"Test",[],CancellationToken.None); MessageBox.Show(result["Message"],"Verbindungstest"); });
        summaryBox=new TextBox { IsReadOnly=true,AcceptsReturn=true,TextWrapping=TextWrapping.Wrap,MinHeight=300,FontFamily=new FontFamily("Consolas"),VerticalScrollBarVisibility=ScrollBarVisibility.Auto }; overview.Children.Add(summaryBox);

        var exchange=Page("Microsoft 365","Tenant als ursprüngliche onmicrosoft.com-Domäne. Zertifikat mit privatem Schlüssel liegt in LocalMachine\\My. Die App benötigt zusätzlich Exchange-Rollenrechte.");
        Field(exchange,"Tenant / Organisation",settings,nameof(Settings.Tenant)); Field(exchange,"Application (Client) ID",settings,nameof(Settings.AppId));
        var thumb=Field(exchange,"Zertifikat-Thumbprint",settings,nameof(Settings.Thumbprint));
        Field(exchange,"Vollständiger Pfad zu PowerShell 7 (pwsh.exe)",settings,nameof(Settings.PowerShellPath));
        Field(exchange,"Zertifikatwarnung ab Restlaufzeit in Tagen",settings,nameof(Settings.CertificateWarningDays));
        var certInfo=new TextBlock { TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,8,0,12) }; exchange.Children.Add(certInfo);
        ActionButton(exchange,"Zertifikat prüfen",async()=> { Collect(); var c=await PowerShell.Certificate(settings,"Inspect",CancellationToken.None); certInfo.Text=$"{c.Subject}\nGültig: {c.NotBefore:g} – {c.NotAfter:g}\nPrivater Schlüssel zugänglich: {c.HasPrivateKey}"; });
        ActionButton(exchange,"Zertifikat erstellen (1 Jahr)",async()=> { Collect(); var c=await PowerShell.Certificate(settings,"Create",CancellationToken.None); settings.Thumbprint=c.Thumbprint; thumb.Text=c.Thumbprint; certInfo.Text=$"Erstellt: {c.Thumbprint}\nÖffentlichen Teil exportieren und in Entra hochladen; anschließend Einstellungen speichern."; });
        ActionButton(exchange,"Öffentlichen Teil exportieren (.cer)",async()=> { Collect(); var c=await PowerShell.Certificate(settings,"Inspect",CancellationToken.None); var dialog=new SaveFileDialog { FileName="AbwesenheitsManager.cer",Filter="Öffentliches Zertifikat|*.cer" }; if(dialog.ShowDialog()==true) await File.WriteAllBytesAsync(dialog.FileName,Convert.FromBase64String(c.PublicBase64)); });

        var templates=Page("Vorlagen","HTML für interne und externe Empfänger. Platzhalter sind ausschließlich in Textknoten erlaubt. Bei Abweichungen wird die betroffene Nachricht vollständig auf ihre Vorlage zurückgesetzt; variable Werte dieser Nachricht gehen dabei verloren.");
        Field(templates,"Interne HTML-Vorlage",settings,nameof(Settings.InternalHtml),true); Field(templates,"Externe HTML-Vorlage",settings,nameof(Settings.ExternalHtml),true);
        Label(templates,"Vorlagenprüfung ohne Exchange: bestehende HTML-Nachricht einsetzen");
        var sample=new TextBox { AcceptsReturn=true,Height=120,VerticalScrollBarVisibility=ScrollBarVisibility.Auto }; templates.Children.Add(sample);
        var external=new CheckBox { Content="Gegen externe Vorlage prüfen" }; templates.Children.Add(external);
        ActionButton(templates,"Text lokal prüfen",()=> { Collect(); var ok=Templates.Matches(sample.Text,external.IsChecked==true?settings.ExternalHtml:settings.InternalHtml,settings.Variables); MessageBox.Show(ok?"Zulässig – feste Teile und Variablen stimmen.":"Abweichung – diese Nachricht würde durch die Standardvorlage ersetzt."); return Task.CompletedTask; });

        var variablePage=Page("Variablen","Beliebig viele Variablen hinzufügen oder markierte Zeilen mit Entf löschen. Regex prüft den gesamten Variablenwert; leer bedeutet keine zusätzliche Prüfung. Platzhalter dürfen nicht überlappen oder direkt aneinandergrenzen.");
        variables=new ObservableCollection<Variable>(settings.Variables);
        variableGrid=new DataGrid { ItemsSource=variables,CanUserAddRows=true,CanUserDeleteRows=true,MinHeight=320 };
        foreach(var (name,property) in new[]{("Name","Name"),("Platzhalter","Placeholder"),("Beschreibung","Description"),("Regex (optional)","ValidationPattern")}) variableGrid.Columns.Add(new DataGridTextColumn { Header=name,Binding=new Binding(property) { UpdateSourceTrigger=UpdateSourceTrigger.PropertyChanged },Width=new DataGridLength(1,DataGridLengthUnitType.Star) });
        variablePage.Children.Add(variableGrid);

        var automation=Page("Betrieb","Dienst und GUI teilen Einstellungen und letzte Laufzusammenfassung in ProgramData. Zeitplanänderungen werden innerhalb von 15 Sekunden erkannt; ein laufender Durchlauf verwendet seinen bisherigen Stand.");
        Toggle(automation,"Dry-Run / Testmodus (keine Exchange-Änderungen)",settings,nameof(Settings.DryRun));
        Toggle(automation,"Automatische Dienstläufe aktivieren",settings,nameof(Settings.SchedulerEnabled));
        Field(automation,"Intervall in Minuten",settings,nameof(Settings.IntervalMinutes)); Field(automation,"Zeitlimit je PowerShell-Aufruf in Minuten",settings,nameof(Settings.TimeoutMinutes));
        Label(automation,"Log-Stufe"); var log=new ComboBox { ItemsSource=Enum.GetValues<LogLevel>(),SelectedItem=settings.LogLevel,Margin=new Thickness(0,0,0,10) }; automation.Children.Add(log); readers.Add(()=>settings.LogLevel=(LogLevel)log.SelectedItem);
        Label(automation,"Ausgeschlossene primäre SMTP-Adressen (eine pro Zeile, keine Wildcards)"); var exclusions=new TextBox { Text=string.Join(Environment.NewLine,settings.ExcludedMailboxes),AcceptsReturn=true,MinHeight=130,VerticalScrollBarVisibility=ScrollBarVisibility.Auto }; automation.Children.Add(exclusions);
        readers.Add(()=>settings.ExcludedMailboxes=exclusions.Text.Split(['\r','\n'],StringSplitOptions.RemoveEmptyEntries|StringSplitOptions.TrimEntries).Distinct(StringComparer.OrdinalIgnoreCase).ToList());
        automation.Children.Add(new TextBlock { Text="Dienst installieren/starten: mitgelieferte Skripte, siehe README. Logs: "+Path.Combine(Storage.Root,"Logs"),TextWrapping=TextWrapping.Wrap });

        var smtp=Page("SMTP","Eine Sammelmeldung pro Lauf, wenn ausgewählte Ereignisse auftreten. Unterstützt STARTTLS (typisch Port 587), kein implizites TLS auf Port 465 und kein OAuth-SMTP. Alternativ ein geeignetes internes Relay ohne Anmeldung verwenden.");
        Toggle(smtp,"SMTP-Benachrichtigungen aktivieren",settings.Smtp,nameof(SmtpSettings.Enabled));
        Field(smtp,"SMTP-Host",settings.Smtp,nameof(SmtpSettings.Host)); Field(smtp,"Port",settings.Smtp,nameof(SmtpSettings.Port)); Toggle(smtp,"STARTTLS verwenden",settings.Smtp,nameof(SmtpSettings.StartTls));
        Field(smtp,"Benutzername (leer für Relay ohne Anmeldung)",settings.Smtp,nameof(SmtpSettings.Username));
        Label(smtp,"Neues Passwort (leer = gespeichertes Passwort behalten)"); password=new PasswordBox(); smtp.Children.Add(password); clearPassword=new CheckBox { Content="Gespeichertes Passwort löschen" }; smtp.Children.Add(clearPassword);
        Field(smtp,"Absender",settings.Smtp,nameof(SmtpSettings.From)); Field(smtp,"Admin-Empfänger",settings.Smtp,nameof(SmtpSettings.Recipient));
        Toggle(smtp,"Bei Warnungen senden",settings.Smtp,nameof(SmtpSettings.OnWarnings)); Toggle(smtp,"Bei Fehlern senden",settings.Smtp,nameof(SmtpSettings.OnErrors));
        Field(smtp,"Betreff",settings.Smtp,nameof(SmtpSettings.Subject)); Field(smtp,"Einleitung der Sammelmeldung",settings.Smtp,nameof(SmtpSettings.Introduction),true);
        ActionButton(smtp,"SMTP-Testnachricht senden",async()=> { Collect(); using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(30)); await SmtpNotifier.Send(settings.Smtp,"Dies ist eine Testnachricht des AbwesenheitsManagers.",timeout.Token); MessageBox.Show("SMTP-Testnachricht gesendet."); });
        RefreshSummary();
    }
    private void RefreshSummary()
    {
        try
        {
            if(!File.Exists(Path.Combine(Storage.Root,"last-run.json"))) { summaryHeadline.Text="Noch kein Lauf · zuerst Verbindung und Dry-Run prüfen"; summaryBox.Text="Hier erscheinen nach dem ersten Lauf die Warnungen, Fehler und geplanten oder ausgeführten Korrekturen."; return; }
            var run=Storage.Read<RunSummary>("last-run.json");
            summaryHeadline.Text=$"{(run.DryRun?"Dry-Run":"Produktivlauf")} · {run.Finished:g}\n{run.Checked} geprüft · {run.Skipped} übersprungen · {run.Valid} korrekt · {run.WouldChange} geplant · {run.Changed} geändert · {run.Errors.Count} Fehler";
            var lines=new List<string> { $"Beginn: {run.Started:g}", $"Ende: {run.Finished:g}", $"Ergebnis: {(run.Success?"Ohne Fehler abgeschlossen":"Mit Fehlern abgeschlossen")}", "" };
            if(run.Warnings.Count>0) { lines.Add("WARNUNGEN"); lines.AddRange(run.Warnings.Select(x=>"• "+x)); lines.Add(""); }
            if(run.Errors.Count>0) { lines.Add("FEHLER"); lines.AddRange(run.Errors.Select(x=>"• "+x)); lines.Add(""); }
            if(run.Results.Count>0) { lines.Add("POSTFÄCHER"); lines.AddRange(run.Results.Select(x=>$"{x.Identity} · {x.Outcome switch { "Planned"=>"Geplant", "Changed"=>"Korrigiert", "Skipped"=>"Übersprungen", _=>"Fehler" }}: {x.Detail}")); }
            summaryBox.Text=string.Join(Environment.NewLine,lines);
        }
        catch(Exception ex) { summaryHeadline.Text="Zusammenfassung nicht lesbar: "+ex.Message; }
    }
}
