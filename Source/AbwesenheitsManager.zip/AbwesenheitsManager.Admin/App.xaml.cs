using System.Windows;
namespace AbwesenheitsManager.Admin;
public partial class App : Application { }
