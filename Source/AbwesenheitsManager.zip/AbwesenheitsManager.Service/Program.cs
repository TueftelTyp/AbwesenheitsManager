using AbwesenheitsManager.Core;
using AbwesenheitsManager.Exchange;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using CoreLogLevel=AbwesenheitsManager.Core.LogLevel;

Storage.Initialize();
var builder=Host.CreateApplicationBuilder(args);
builder.Services.AddWindowsService(o=>o.ServiceName="AbwesenheitsManager");
builder.Services.AddHostedService<Worker>();
await builder.Build().RunAsync();

sealed class Worker : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        DateTimeOffset? last=null;
        if(File.Exists(Path.Combine(Storage.Root,"last-run.json")))
            try { last=Storage.Read<RunSummary>("last-run.json").Finished; } catch(Exception ex) { Storage.Log(new Settings(),CoreLogLevel.Error,ex.Message); }
        while(!stoppingToken.IsCancellationRequested)
        {
            var s=new Settings();
            try
            {
                s=Storage.Load(); Templates.Validate(s);
                if(s.SchedulerEnabled && (last is null || DateTimeOffset.Now>=last.Value.AddMinutes(s.IntervalMinutes)))
                {
                    await new Runner().Run(s,false,stoppingToken);
                    last=DateTimeOffset.Now;
                }
            }
            catch(Exception ex) { Storage.Log(s,CoreLogLevel.Error,"Dienst: "+ex.Message); last=DateTimeOffset.Now; }
            try { await Task.Delay(TimeSpan.FromSeconds(15),stoppingToken); } catch(OperationCanceledException) { break; }
        }
    }
}
