using AbwesenheitsManager.Core;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using AbwesenheitsManager.Admin;
static class Program
{
[STAThread]
static void Main(string[] args)
{
if(args.Length==2 && args[0]=="--render")
{
    var app=new App(); app.InitializeComponent();
    var window=new MainWindow(new Settings());
    var content=(FrameworkElement)window.Content;
    content.Measure(new Size(1180,820)); content.Arrange(new Rect(0,0,1180,820)); content.UpdateLayout();
    var image=new RenderTargetBitmap(1180,820,96,96,PixelFormats.Pbgra32); image.Render(content);
    var encoder=new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(image));
    using var file=File.Create(args[1]); encoder.Save(file);
    Console.WriteLine("WPF-Oberfläche erfolgreich instanziiert und gerendert."); return;
}
var passed=0;
void Check(string name,bool result) { if(!result) throw new Exception("FAIL: "+name); Console.WriteLine("PASS: "+name); passed++; }
void Reject(string name,Action action) { try { action(); } catch(ArgumentException) { Check(name,true); return; } throw new Exception("FAIL: "+name); }
var s=new Settings(); Templates.Validate(s);
Check("Standardvorlage mit unveränderten Platzhaltern",Templates.Matches(s.InternalHtml,s.InternalHtml,s.Variables));
var filled=s.InternalHtml.Replace("[Datum]","31.10.2026").Replace("[Vertretung]","Erika Muster").Replace("[E-Mail-Adresse]","erika@example.org").Replace("[Telefonnummer]","+49 123 456");
Check("Nur Variablen geändert",Templates.Matches(filled,s.InternalHtml,s.Variables));
Check("Fester Text geändert",!Templates.Matches(filled.Replace("Vielen Dank","Danke"),s.InternalHtml,s.Variables));
Check("Regex greift",!Templates.Matches(filled.Replace("erika@example.org","keine Adresse"),s.InternalHtml,s.Variables));
Check("Kein HTML im Variablenbereich",!Templates.Matches(filled.Replace("Erika Muster","<i>Erika Muster</i>"),s.InternalHtml,s.Variables));
Check("Entities äquivalent",Templates.Matches(filled.Replace("Erika Muster","Erika &amp; Max"),s.InternalHtml,s.Variables));
Check("Aktiv wird übersprungen",Templates.Plan(new("x@example.org","Enabled","falsch","falsch"),s) is null);
Check("Geplant wird übersprungen",Templates.Plan(new("x@example.org","Scheduled","falsch","falsch"),s) is null);
Check("Unbekannter Status wird übersprungen",Templates.Plan(new("x@example.org","Unexpected","falsch","falsch"),s) is null);
s.ExcludedMailboxes.Add("X@example.org");
Check("Ausschluss ohne Beachtung der Großschreibung",Templates.Plan(new("x@example.org","Disabled","falsch","falsch"),s) is null); s.ExcludedMailboxes.Clear();
var change=Templates.Plan(new("x@example.org","Disabled",filled,"falsch"),s)!;
Check("Nur externe Seite korrigiert",change.InternalHtml is null && change.ExternalHtml==s.ExternalHtml);
Check("Gültige Variablen bleiben erhalten",Templates.Plan(new("x@example.org","Disabled",filled,filled),s) is null);
Check("Leere Antwort wird initialisiert",Templates.Plan(new("x@example.org","Disabled","",""),s) is not null);
Check("Wrapper normalisiert",Templates.Matches("<html><head><meta charset='utf-8'></head><body><p>Test</p></body></html>","<p>Test</p>",[]));
Check("Feste Attribute geschützt",!Templates.Matches("<p style='color:red'>Test</p>","<p>Test</p>",[]));
var repeat=new List<Variable> { new() { Name="X",Placeholder="[X]" } };
Check("Wiederholte Variable konsistent",Templates.Matches("<p>A / A</p>","<p>[X] / [X]</p>",repeat));
Check("Wiederholte Variable inkonsistent",!Templates.Matches("<p>A / B</p>","<p>[X] / [X]</p>",repeat));
Reject("Ungültige Regex",()=>Templates.Validate(new Settings { Variables=[new(){Name="X",Placeholder="[X]",ValidationPattern="("}] }));
Reject("Doppelte Platzhalter",()=>Templates.Validate(new Settings { Variables=[new(){Name="A",Placeholder="[X]"},new(){Name="B",Placeholder="[X]"}] }));
Reject("Benachbarte Platzhalter",()=>Templates.Validate(new Settings {InternalHtml="[A][B]",Variables=[new(){Name="A",Placeholder="[A]"},new(){Name="B",Placeholder="[B]"}] }));
Reject("Platzhalter in Attribut",()=>Templates.Validate(new Settings {InternalHtml="<a href='[Datum]'>Link</a>"}));
Reject("Ungültiges Intervall",()=>Templates.Validate(new Settings {IntervalMinutes=0}));
var secret=Storage.Protect("Test-Passwort-äöü"); Check("DPAPI LocalMachine roundtrip",Storage.Unprotect(secret)=="Test-Passwort-äöü");
Console.WriteLine($"{passed} Tests erfolgreich.");
}
}
