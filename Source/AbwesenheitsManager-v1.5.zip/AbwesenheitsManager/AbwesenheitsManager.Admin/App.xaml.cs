using System.Windows;
namespace AbwesenheitsManager.Admin;
public partial class App : Application
{
    public static bool SessionIsEnding { get; private set; }
    protected override void OnSessionEnding(SessionEndingCancelEventArgs e)
    {
        SessionIsEnding = true;
        base.OnSessionEnding(e);
    }
}
