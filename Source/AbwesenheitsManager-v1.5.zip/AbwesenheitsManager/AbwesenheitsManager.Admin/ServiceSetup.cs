using System.Diagnostics;
using System.IO;
using System.ServiceProcess;
using System.Security.AccessControl;
using Microsoft.Win32;
using AbwesenheitsManager.Core;

namespace AbwesenheitsManager.Admin;

public static class ServiceSetup
{
    public static async Task Disable()
    {
        using var key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\" + TraySupport.ServiceName);
        if (key is null) return;
        // Disable before stopping so recovery and the next reboot cannot start it again.
        await Sc("config", TraySupport.ServiceName, "start=", "disabled");
        await Task.Run(() =>
        {
            using var service = new ServiceController(TraySupport.ServiceName);
            service.Refresh();
            if (service.Status == ServiceControllerStatus.StartPending)
                service.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(90));
            service.Refresh();
            if (service.Status != ServiceControllerStatus.Stopped && service.Status != ServiceControllerStatus.StopPending)
                service.Stop();
            service.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(90));
        });
    }
    private static string InstalledDirectory => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "AbwesenheitsManager.ServiceHost", "Service");

    public static async Task EnsureRunning()
    {
        using var key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\" + TraySupport.ServiceName);
        if (key is null)
        {
            var source = Path.GetDirectoryName(TraySupport.FindApp("Service"))!;
            var packageDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "AbwesenheitsManager", "Service");
            var destination = string.Equals(Path.GetFullPath(source).TrimEnd(Path.DirectorySeparatorChar), packageDirectory, StringComparison.OrdinalIgnoreCase)
                ? packageDirectory : InstalledDirectory;
            if (destination == packageDirectory)
            {
                RejectLinks(destination);
                ValidateEntry(destination);
                Protect(destination);
            }
            else
            {
            ValidateSourceDirectory(source, destination);
            // Program Files supplies a machine-wide location which standard users cannot modify.
            // Never replace an existing installation implicitly.
            if (Directory.Exists(destination))
                throw new IOException("Der Dienstordner existiert bereits, aber der Dienst fehlt: " + destination + ". Bitte die vorhandene Installation prüfen.");
            var parent = Path.GetDirectoryName(destination)!;
            RejectLinks(parent);
            Directory.CreateDirectory(parent);
            RejectLinks(parent);
            Protect(parent);
            var staging = Path.Combine(parent, "Service-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(staging);
            // Use the same ACL hardening as the supplied installation script before copying executable files.
            Protect(staging);
            foreach (var directory in Directory.GetDirectories(source, "*", SearchOption.AllDirectories))
                Directory.CreateDirectory(Path.Combine(staging, Path.GetRelativePath(source, directory)));
            foreach (var file in Directory.GetFiles(source, "*", SearchOption.AllDirectories))
                File.Copy(file, Path.Combine(staging, Path.GetRelativePath(source, file)));
            Directory.Move(staging, destination);
            }
            await Sc("create", TraySupport.ServiceName, "binPath=", "\"" + Path.Combine(destination, "AbwesenheitsManager.Service.exe") + "\"",
                "start=", "auto", "DisplayName=", "AbwesenheitsManager");
        }
        await Sc("config", TraySupport.ServiceName, "start=", "auto");
        await Sc("failure", TraySupport.ServiceName, "reset=", "86400", "actions=", "restart/60000/restart/120000/restart/300000");
        await Task.Run(() =>
        {
            using var service = new ServiceController(TraySupport.ServiceName);
            if (service.Status == ServiceControllerStatus.StopPending)
                service.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(30));
            service.Refresh();
            if (service.Status == ServiceControllerStatus.Stopped) service.Start();
            else if (service.Status == ServiceControllerStatus.Paused) service.Continue();
            service.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(30));
        });
    }

    public static void ValidateSourceDirectory(string source, string destination)
    {
        source = Path.GetFullPath(source);
        destination = Path.GetFullPath(destination);
        if (source.StartsWith(@"\\", StringComparison.Ordinal) ||
            destination.StartsWith(source.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) ||
            string.Equals(source, destination, StringComparison.OrdinalIgnoreCase))
            throw new IOException("Ungültiger Dienst-Quellordner.");
        RejectLinks(source);
        foreach (var entry in Directory.EnumerateFileSystemEntries(source, "*", SearchOption.TopDirectoryOnly))
            ValidateEntry(entry);
        if (!File.Exists(Path.Combine(source, "AbwesenheitsManager.Service.exe")))
            throw new FileNotFoundException("Dienstdateien fehlen. Bitte die vollständige veröffentlichte Anwendung verwenden.");
    }

    private static void ValidateEntry(string path)
    {
        if ((File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0)
            throw new IOException("Verknüpfungen im Dienstordner sind nicht zulässig: " + path);
        if (Directory.Exists(path))
            foreach (var child in Directory.EnumerateFileSystemEntries(path)) ValidateEntry(child);
    }
    private static void RejectLinks(string path)
    {
        for (var directory = new DirectoryInfo(path); directory is not null; directory = directory.Parent)
            if (directory.Exists && (directory.Attributes & FileAttributes.ReparsePoint) != 0)
                throw new IOException("Verknüpfter Installationspfad ist nicht zulässig: " + directory.FullName);
    }
    private static void Protect(string path)
    {
        var acl = new System.Security.AccessControl.DirectorySecurity();
        acl.SetAccessRuleProtection(true, false);
        foreach (var sid in new[] { "S-1-5-18", "S-1-5-32-544" })
            acl.AddAccessRule(new System.Security.AccessControl.FileSystemAccessRule(
                new System.Security.Principal.SecurityIdentifier(sid), System.Security.AccessControl.FileSystemRights.FullControl,
                System.Security.AccessControl.InheritanceFlags.ContainerInherit | System.Security.AccessControl.InheritanceFlags.ObjectInherit,
                System.Security.AccessControl.PropagationFlags.None, System.Security.AccessControl.AccessControlType.Allow));
        new DirectoryInfo(path).SetAccessControl(acl);
    }
    private static async Task Sc(params string[] arguments)
    {
        var info = new ProcessStartInfo(Path.Combine(Environment.SystemDirectory, "sc.exe"))
        { UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true };
        foreach (var argument in arguments) info.ArgumentList.Add(argument);
        using var process = Process.Start(info) ?? throw new IOException("Dienstverwaltung konnte nicht gestartet werden.");
        var output = process.StandardOutput.ReadToEndAsync();
        var error = process.StandardError.ReadToEndAsync();
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        try { await process.WaitForExitAsync(timeout.Token); }
        catch (OperationCanceledException) { process.Kill(); throw new IOException("Zeitlimit bei der Dienstverwaltung überschritten."); }
        if (process.ExitCode != 0) throw new IOException("Dienstverwaltung fehlgeschlagen: " + await output + await error);
    }
}
