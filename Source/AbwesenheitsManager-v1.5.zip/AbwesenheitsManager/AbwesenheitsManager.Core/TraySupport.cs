using Microsoft.Win32;
using System.Diagnostics;
using System.Security.AccessControl;
using System.Security.Principal;
using System.ServiceProcess;
using System.Text.Json;

namespace AbwesenheitsManager.Core;

public sealed record TraySnapshot(DateTimeOffset Updated, DateTimeOffset? Last, DateTimeOffset? Next,
    bool Enabled, bool Running, int Warnings, int Errors);

public static class TraySupport
{
    public const string ServiceName = "AbwesenheitsManager";
    public const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
    public const string RunValue = "AbwesenheitsManager.Tray";
    public static string StatusRoot => Storage.Root + ".Status";
    public static string StatusFile => Path.Combine(StatusRoot, "status.json");

    // A separate directory keeps settings, SMTP secrets and mailbox details private.
    public static void InitializeStatus()
    {
        var dir = Directory.CreateDirectory(StatusRoot);
        var acl = new DirectorySecurity();
        acl.SetAccessRuleProtection(true, false);
        foreach (var sid in new[] { WellKnownSidType.BuiltinAdministratorsSid, WellKnownSidType.LocalSystemSid })
            acl.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(sid, null), FileSystemRights.FullControl,
                InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow));
        acl.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(WellKnownSidType.BuiltinUsersSid, null), FileSystemRights.ReadAndExecute,
            InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow));
        dir.SetAccessControl(acl);
    }

    public static void PublishStatus(Settings settings, DateTimeOffset? next, bool running = false, bool failed = false)
    {
        try
        {
            RunSummary? run = File.Exists(Path.Combine(Storage.Root, "last-run.json")) ? Storage.Read<RunSummary>("last-run.json") : null;
            var value = new TraySnapshot(DateTimeOffset.UtcNow, run?.Finished, next, settings.SchedulerEnabled, running,
                run?.Warnings.Count ?? 0, Math.Max(run?.Errors.Count ?? 0, failed ? 1 : 0));
            var temp = StatusFile + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try { File.WriteAllText(temp, JsonSerializer.Serialize(value, Storage.Json)); File.Move(temp, StatusFile, true); }
            finally { if (File.Exists(temp)) File.Delete(temp); }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or JsonException) { /* Status must never interrupt a run. */ }
    }

    public static (string State, TraySnapshot? Snapshot) ReadStatus()
    {
        try
        {
            using var service = new ServiceController(ServiceName);
            using var serviceKey = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\" + ServiceName);
            if (service.Status == ServiceControllerStatus.Stopped && serviceKey?.GetValue("Start") is int start && start == 4)
                return ("Inaktiv: automatische Dienstläufe deaktiviert", null);
            if (service.Status != ServiceControllerStatus.Running) return ("Fehler: Dienst " + service.Status, null);
            var snapshot = JsonSerializer.Deserialize<TraySnapshot>(File.ReadAllText(StatusFile), Storage.Json);
            var state = EvaluateSnapshot(snapshot, DateTimeOffset.UtcNow);
            return (state, state.StartsWith("Unbekannt", StringComparison.Ordinal) ? null : snapshot);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or JsonException or InvalidOperationException or System.ComponentModel.Win32Exception)
        { return ("Unbekannt: Dienst/Status nicht erreichbar", null); }
    }

    public static string EvaluateSnapshot(TraySnapshot? snapshot, DateTimeOffset now)
    {
        if (snapshot is null || now - snapshot.Updated > TimeSpan.FromSeconds(90) || snapshot.Updated > now.AddSeconds(30))
            return "Unbekannt: Dienst läuft, Status fehlt/veraltet";
        return snapshot.Errors > 0 ? "Fehler beim letzten Lauf/Dienst" : snapshot.Warnings > 0 ? "Warnung beim letzten Lauf" : "Läuft";
    }

    public static string FindApp(string name)
    {
        var filename = "AbwesenheitsManager." + name + ".exe";
        var candidates = new[] { Path.Combine(AppContext.BaseDirectory, filename), Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", name, filename)) };
        return candidates.FirstOrDefault(File.Exists) ?? throw new FileNotFoundException("Programm fehlt. Vollständigen publish-Ordner mit Admin, Service und Tray bereitstellen.", filename);
    }
    public static bool AutoStartEnabled
    {
        get { using var key = Registry.CurrentUser.OpenSubKey(RunKey); return key?.GetValue(RunValue) is string; }
    }
    public static void SetAutoStart(bool enabled)
    {
        var command = enabled ? "\"" + FindApp("Tray") + "\"" : null;
        using var key = Registry.CurrentUser.CreateSubKey(RunKey);
        if (enabled) key.SetValue(RunValue, command!, RegistryValueKind.String);
        else key.DeleteValue(RunValue, false);
        using var preferences = Registry.CurrentUser.CreateSubKey(@"Software\AbwesenheitsManager");
        preferences.SetValue("TrayAutostartConfigured", 1, RegistryValueKind.DWord);
    }
    public static void StartTrayAfterAdmin()
    {
        var executable = FindApp("Tray");
        using var preferences = Registry.CurrentUser.OpenSubKey(@"Software\AbwesenheitsManager");
        if (preferences?.GetValue("TrayAutostartConfigured") is null) SetAutoStart(true);
        using var process = Process.Start(new ProcessStartInfo(executable) { UseShellExecute = true });
    }
    public static bool AdminIsOpen()
    {
        using var current = Process.GetCurrentProcess();
        var processes = Process.GetProcessesByName("AbwesenheitsManager.Admin");
        try { return processes.Any(p => { try { return p.SessionId == current.SessionId; } catch (Exception ex) when (ex is InvalidOperationException or System.ComponentModel.Win32Exception) { return false; } }); }
        finally { foreach (var process in processes) process.Dispose(); }
    }
    public static void OpenAdmin(bool check) => Process.Start(new ProcessStartInfo(FindApp("Admin"))
        { UseShellExecute = true, Arguments = check ? "--check" : "" });
}
