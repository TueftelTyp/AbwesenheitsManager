using AbwesenheitsManager.Core;
using System.Drawing;

namespace AbwesenheitsManager.Tray;
internal static class Program
{
    [STAThread]
    private static void Main(string[] args)
    {
        ApplicationConfiguration.Initialize();
        if (args.Contains("--enable-autostart") || args.Contains("--disable-autostart"))
        {
            try { TraySupport.SetAutoStart(args.Contains("--enable-autostart")); }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Tray-Autostart"); }
            return;
        }
        using var mutex = new Mutex(true, @"Local\AbwesenheitsManager.Tray", out var first);
        if (!first) return;
        try { using var context = new TrayContext(); Application.Run(context); }
        finally { mutex.ReleaseMutex(); }
    }
}

internal sealed class TrayContext : ApplicationContext
{
    private readonly NotifyIcon icon = new();
    private readonly ContextMenuStrip menu = new();
    private readonly System.Windows.Forms.Timer timer = new() { Interval = 15000 };
    private readonly System.Windows.Forms.Timer visibilityTimer = new() { Interval = 500 };
    private readonly ToolStripMenuItem status = new() { Enabled = false };
    private readonly ToolStripMenuItem last = new() { Enabled = false };
    private readonly ToolStripMenuItem next = new() { Enabled = false };
    // User-supplied application icon with a small status badge.
    private readonly Dictionary<string, Icon> icons = new()
    {
        ["L"] = Dot(Color.ForestGreen), ["W"] = Dot(Color.Goldenrod),
        ["F"] = Dot(Color.Firebrick), ["U"] = Dot(Color.Gray), ["I"] = Dot(Color.Gray)
    };
    public TrayContext()
    {
        menu.Items.AddRange([status, last, next, new ToolStripSeparator()]);
        menu.Items.Add("Admin-Oberfläche öffnen", null, (_, _) => Open(false));
        menu.Items.Add("Jetzt prüfen", null, (_, _) => Open(true));
        menu.Items.Add("Dienststatus aktualisieren", null, (_, _) => Refresh());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Beenden", null, (_, _) => ExitThread());
        icon.ContextMenuStrip = menu;
        icon.DoubleClick += (_, _) => Open(false);
        menu.Opening += (_, _) => Refresh();
        timer.Tick += (_, _) => Refresh();
        visibilityTimer.Tick += (_, _) => icon.Visible = !TraySupport.AdminIsOpen();
        Refresh(); icon.Visible = !TraySupport.AdminIsOpen(); timer.Start(); visibilityTimer.Start();
    }
    private void Open(bool check)
    {
        try { TraySupport.OpenAdmin(check); }
        catch (Exception ex) { MessageBox.Show(ex.Message, "AbwesenheitsManager", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }
    private void Refresh()
    {
        var (state, snapshot) = TraySupport.ReadStatus();
        status.Text = "Dienststatus: " + state;
        last.Text = "Letzte Prüfung: " + (snapshot?.Last?.ToLocalTime().ToString("g") ?? "unbekannt / noch keine");
        next.Text = "Nächste Prüfung: " + (snapshot is null ? "unbekannt" : snapshot.Running ? "Prüfung läuft" : !snapshot.Enabled ? "Zeitplan deaktiviert" : snapshot.Next?.ToLocalTime().ToString("g") ?? "in Kürze");
        icon.Icon = icons[state[..1]];
        var tooltip = "AbwesenheitsManager – " + state;
        icon.Text = tooltip[..Math.Min(tooltip.Length, 63)];
    }
    private static Icon Dot(Color color)
    {
        using var bitmap = new Bitmap(32, 32);
        using var stream = typeof(TrayContext).Assembly.GetManifestResourceStream("AbwesenheitsManager.Icon")
            ?? throw new InvalidOperationException("Programmicon fehlt.");
        using var appIcon = new Icon(stream, 32, 32);
        using (var graphics = Graphics.FromImage(bitmap))
        using (var brush = new SolidBrush(color))
        { graphics.Clear(Color.Transparent); graphics.DrawIcon(appIcon, new Rectangle(0, 0, 32, 32)); graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias; graphics.FillEllipse(brush, 19, 19, 12, 12); graphics.DrawEllipse(Pens.White, 19, 19, 12, 12); }
        var handle = bitmap.GetHicon();
        try { using var original = Icon.FromHandle(handle); return (Icon)original.Clone(); }
        finally { DestroyIcon(handle); }
    }
    [System.Runtime.InteropServices.DllImport("user32.dll")]
    private static extern bool DestroyIcon(IntPtr handle);
    protected override void Dispose(bool disposing)
    {
        if (disposing) { visibilityTimer.Stop(); visibilityTimer.Dispose(); timer.Stop(); timer.Dispose(); icon.Visible = false; icon.Dispose(); menu.Dispose(); foreach (var value in icons.Values) value.Dispose(); }
        base.Dispose(disposing);
    }
}
