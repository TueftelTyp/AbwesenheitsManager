param([switch]$Disable, [string]$TrayPath=(Join-Path $PSScriptRoot '..\publish\Tray\AbwesenheitsManager.Tray.exe'))
$ErrorActionPreference='Stop'
# Run as the intended interactive user, without elevation.
$key='HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
if($Disable) {
    Remove-ItemProperty -LiteralPath $key -Name 'AbwesenheitsManager.Tray' -ErrorAction SilentlyContinue
} else {
    $exe=(Resolve-Path -LiteralPath $TrayPath).Path
    if([IO.Path]::GetFileName($exe) -ne 'AbwesenheitsManager.Tray.exe') { throw 'Tray-Programm auswählen.' }
    New-Item -Path $key -Force | Out-Null
    New-ItemProperty -LiteralPath $key -Name 'AbwesenheitsManager.Tray' -Value ('"'+$exe+'"') -PropertyType String -Force | Out-Null
}
