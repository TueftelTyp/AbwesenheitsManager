#Requires -Version 7.0
param([string]$Compiler='C:\Program Files (x86)\Inno Setup 6\ISCC.exe')
$ErrorActionPreference='Stop'
if(!(Test-Path -LiteralPath $Compiler)) { throw 'Inno Setup 6 installieren oder -Compiler mit dem vollständigen ISCC.exe-Pfad angeben.' }
& (Join-Path $PSScriptRoot 'Publish.ps1')
& $Compiler (Join-Path $PSScriptRoot '..\Setup\AbwesenheitsManager.iss')
if($LASTEXITCODE -ne 0) { throw 'Setup-Erstellung fehlgeschlagen.' }
