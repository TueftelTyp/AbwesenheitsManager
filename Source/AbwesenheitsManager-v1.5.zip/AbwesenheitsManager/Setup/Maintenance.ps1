#Requires -Version 5.1
#Requires -RunAsAdministrator
param([ValidateSet('Upgrade','Uninstall')][string]$Mode='Uninstall')
$ErrorActionPreference='Stop'
$appRoot=Join-Path $env:ProgramFiles 'AbwesenheitsManager'
$legacyRoot=Join-Path $env:ProgramFiles 'AbwesenheitsManager.ServiceHost'
$dataRoot=Join-Path $env:ProgramData 'AbwesenheitsManager'
$statusRoot=$dataRoot+'.Status'
$logPath=Join-Path $env:ProgramData 'AbwesenheitsManager-maintenance.log'

function Assert-NoLinks([string]$Path) {
    $item=Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue
    if(!$item) { return }
    if($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Verknüpfung nicht zulässig: $Path" }
    if($item.PSIsContainer) {
        foreach($child in Get-ChildItem -LiteralPath $Path -Force) { Assert-NoLinks $child.FullName }
    }
}
function Remove-OwnedDirectory([string]$Path) {
    $resolved=[IO.Path]::GetFullPath($Path).TrimEnd('\')
    if($resolved -notin @($legacyRoot,$dataRoot,$statusRoot)) { throw "Unzulässiges Löschziel: $resolved" }
    if(Test-Path -LiteralPath $resolved) {
        Assert-NoLinks $resolved
        Remove-Item -LiteralPath $resolved -Recurse -Force
    }
}
function Remove-UserSettings([string]$Hive) {
    $run="Registry::HKEY_USERS\$Hive\Software\Microsoft\Windows\CurrentVersion\Run"
    if(Test-Path -LiteralPath $run) { Remove-ItemProperty -LiteralPath $run -Name 'AbwesenheitsManager.Tray' -ErrorAction SilentlyContinue }
    $preferences="Registry::HKEY_USERS\$Hive\Software\AbwesenheitsManager"
    if(Test-Path -LiteralPath $preferences) { Remove-Item -LiteralPath $preferences -Recurse -Force }
}
try {
    # Do not force-close Admin: a manual Exchange run or unsaved settings could be active.
    if(Get-Process -Name AbwesenheitsManager.Admin -ErrorAction SilentlyContinue) {
        throw 'Admin-Fenster zuerst schließen und laufende Aktionen beenden.'
    }
    foreach($tray in Get-Process -Name AbwesenheitsManager.Tray -ErrorAction SilentlyContinue) {
        # This application name is dedicated to the product; stop its sessions before removing autostart.
        Stop-Process -Id $tray.Id -Force -ErrorAction Stop
    }
    $service=Get-Service -Name AbwesenheitsManager -ErrorAction SilentlyContinue
    if($service) {
        Set-Service -Name AbwesenheitsManager -StartupType Disabled
        if($service.Status -ne 'Stopped') { Stop-Service -Name AbwesenheitsManager -ErrorAction Stop }
        $service.WaitForStatus('Stopped',[TimeSpan]::FromSeconds(90))
        $service.Dispose()
        & "$env:SystemRoot\System32\sc.exe" delete AbwesenheitsManager | Out-Null
        if($LASTEXITCODE -ne 0) { throw 'Dienst konnte nicht gelöscht werden.' }
        if(Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Services\AbwesenheitsManager') {
            throw 'Dienst ist zur Löschung vorgemerkt. Dienste-Verwaltung schließen oder Windows neu starten und erneut versuchen.'
        }
    }
    Remove-OwnedDirectory $legacyRoot
    if($Mode -eq 'Uninstall') {
        # Loaded and unloaded local profiles, including the original non-admin account.
        $profiles=Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList\*'
        foreach($profile in $profiles) {
            $sid=$profile.PSChildName
            if($sid -notmatch '^S-1-(5-21|12-1)-') { continue }
            if(Test-Path "Registry::HKEY_USERS\$sid") { Remove-UserSettings $sid; continue }
            $hiveFile=Join-Path ([Environment]::ExpandEnvironmentVariables($profile.ProfileImagePath)) 'NTUSER.DAT'
            if(!(Test-Path -LiteralPath $hiveFile)) { continue }
            $mount='AbwesenheitsManager_Uninstall_'+[Guid]::NewGuid().ToString('N')
            & "$env:SystemRoot\System32\reg.exe" load "HKU\$mount" $hiveFile | Out-Null
            if($LASTEXITCODE -ne 0) { throw "Benutzerprofil nicht zugänglich: $sid" }
            try { Remove-UserSettings $mount }
            finally {
                [GC]::Collect(); [GC]::WaitForPendingFinalizers()
                & "$env:SystemRoot\System32\reg.exe" unload "HKU\$mount" | Out-Null
                if($LASTEXITCODE -ne 0) { throw "Benutzerprofil konnte nicht entladen werden: $sid" }
            }
        }
        Remove-OwnedDirectory $dataRoot
        Remove-OwnedDirectory $statusRoot
    }
    if(Test-Path -LiteralPath $logPath) { Remove-Item -LiteralPath $logPath -Force }
    exit 0
} catch {
    $_ | Out-String | Set-Content -LiteralPath $logPath -Encoding UTF8
    exit 1
}
