namespace AbwesenheitsManager.Core;

public static class SafeDiagnostics
{
    // Exception messages are external data and may contain credentials or message bodies.
    public static string Describe(Exception error) => error switch
    {
        UnauthorizedAccessException => "AM_ACCESS: Sicherheitsprüfung oder Zugriffsberechtigung fehlgeschlagen.",
        System.Text.RegularExpressions.RegexMatchTimeoutException => "AM_REGEX_TIMEOUT: Zeitlimit der Vorlagenprüfung erreicht.",
        ArgumentException => "AM_CONFIG: Konfiguration oder Vorlage ungültig; Einstellungen prüfen.",
        OperationCanceledException => "AM_TIMEOUT: Vorgang abgebrochen oder Zeitlimit erreicht.",
        System.Net.Mail.SmtpException => "AM_SMTP: SMTP-Verbindung, Anmeldung oder Zustellung fehlgeschlagen.",
        _ => "AM_OPERATION: Vorgang fehlgeschlagen; Verbindung, Zertifikat und Berechtigungen prüfen."
    };
}
