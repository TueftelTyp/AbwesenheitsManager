using System.Net;
using System.Net.Mail;
using System.Text.Json;
namespace AbwesenheitsManager.Core;
public static class SmtpNotifier
{
    public static async Task Send(SmtpSettings s,string body,CancellationToken token)
    {
        ValidateTransport(s);
        using var mail=new MailMessage(s.From,s.Recipient,s.Subject,body);
        using var client=new SmtpClient(s.Host,s.Port) { EnableSsl=s.StartTls, UseDefaultCredentials=false };
        if(!string.IsNullOrWhiteSpace(s.Username)) client.Credentials=new NetworkCredential(s.Username,Storage.Unprotect(s.ProtectedPassword));
        await client.SendMailAsync(mail,token);
    }
    public static void ValidateTransport(SmtpSettings s)
    {
        if (!s.StartTls && !string.IsNullOrWhiteSpace(s.Username))
            throw new ArgumentException("SMTP-Anmeldedaten dürfen ausschließlich mit STARTTLS übertragen werden.");
    }
    // Only counters and times leave the machine; never external error messages or mailbox content.
    public static string Report(RunSummary run) => JsonSerializer.Serialize(new {
        run.Started, run.Finished, run.DryRun, run.Checked, run.Skipped, run.Valid,
        run.WouldChange, run.Changed, WarningCount = run.Warnings.Count, ErrorCount = run.Errors.Count
    }, Storage.Json);
    public static async Task Notify(Settings s,RunSummary run,CancellationToken token)
    {
        if(s.Smtp.Enabled && ((s.Smtp.OnWarnings && run.Warnings.Count>0) || (s.Smtp.OnErrors && run.Errors.Count>0)))
            await Send(s.Smtp,s.Smtp.Introduction+Environment.NewLine+Report(run),token);
    }
}
