using System.Security.AccessControl;
using System.Security.Principal;

namespace AbwesenheitsManager.Core;

public static class SafePaths
{
    private static readonly HashSet<string> Trusted = ["S-1-5-18", "S-1-5-32-544",
        "S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464"];
    private const FileSystemRights Writes = FileSystemRights.Write | FileSystemRights.Delete |
        FileSystemRights.DeleteSubdirectoriesAndFiles | FileSystemRights.ChangePermissions | FileSystemRights.TakeOwnership;

    public static void RejectLinks(string path)
    {
        var full = Path.GetFullPath(path);
        for (var item = full; item is not null; item = Path.GetDirectoryName(item))
        {
            try
            {
                if ((File.GetAttributes(item) & FileAttributes.ReparsePoint) != 0)
                    throw new IOException("Verknüpfte Pfade sind nicht zulässig: " + item);
            }
            catch (FileNotFoundException) { }
            catch (DirectoryNotFoundException) { }
        }
    }

    public static void RequireProtected(string path, bool confidential = false)
    {
        RejectLinks(path);
        FileSystemSecurity acl = Directory.Exists(path) ? new DirectoryInfo(path).GetAccessControl() : new FileInfo(path).GetAccessControl();
        ValidateAcl(acl, confidential);
    }

    public static void ValidateAcl(FileSystemSecurity acl, bool confidential = false)
    {
        var descriptor = new RawSecurityDescriptor(acl.GetSecurityDescriptorBinaryForm(), 0);
        if (descriptor.DiscretionaryAcl is null)
            throw new UnauthorizedAccessException("Fehlende Zugriffsliste ist nicht zulässig.");
        if (acl.GetOwner(typeof(SecurityIdentifier)) is not SecurityIdentifier owner || !Trusted.Contains(owner.Value))
            throw new UnauthorizedAccessException("Pfad gehört keinem vertrauenswürdigen Systemkonto: ");
        foreach (FileSystemAccessRule rule in acl.GetAccessRules(true, true, typeof(SecurityIdentifier)))
            if (rule.AccessControlType == AccessControlType.Allow && (rule.FileSystemRights & (confidential ? FileSystemRights.FullControl : Writes)) != 0 &&
                (rule.PropagationFlags & PropagationFlags.InheritOnly) == 0 &&
                !(confidential ? ((SecurityIdentifier)rule.IdentityReference).Value is "S-1-5-18" or "S-1-5-32-544" : Trusted.Contains(((SecurityIdentifier)rule.IdentityReference).Value)))
                throw new UnauthorizedAccessException("Pfad ist für nicht privilegierte Konten beschreibbar: ");
    }

    public static void RequireProtectedTree(string path, bool confidential = false)
    {
        RequireProtected(path, confidential);
        if (Directory.Exists(path))
            foreach (var child in Directory.EnumerateFileSystemEntries(path)) RequireProtectedTree(child, confidential);
    }

    public static void RequireMachineInstallation(string path)
    {
        var root = Path.GetFullPath(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles)).TrimEnd(Path.DirectorySeparatorChar);
        var full = Path.GetFullPath(path);
        if (!full.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            throw new UnauthorizedAccessException("Privilegierte Programme müssen unter Programme installiert sein: " + full);
        for (var parent = Path.GetDirectoryName(full); parent is not null && parent.Length >= root.Length; parent = Path.GetDirectoryName(parent))
            RequireProtected(parent);
        RequireProtectedTree(full);
    }

    public static void EnsureDataDirectory(string path, bool publicRead = false)
    {
        RejectLinks(path);
        if (Directory.Exists(path)) RequireProtectedTree(path, !publicRead);
        var acl = new DirectorySecurity();
        acl.SetAccessRuleProtection(true, false);
        acl.SetOwner(new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid, null));
        foreach (var sid in new[] { WellKnownSidType.BuiltinAdministratorsSid, WellKnownSidType.LocalSystemSid })
            acl.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(sid, null), FileSystemRights.FullControl,
                InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow));
        if (publicRead) acl.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(WellKnownSidType.BuiltinUsersSid, null),
            FileSystemRights.ReadAndExecute, InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit,
            PropagationFlags.None, AccessControlType.Allow));
        var directory = new DirectoryInfo(path);
        if (!directory.Exists) directory.Create(acl); // Apply security at creation, not after a public creation window.
        else directory.SetAccessControl(acl);
        RequireProtected(path, !publicRead);
    }

    public static string DataFile(string root, string name)
    {
        if (string.IsNullOrWhiteSpace(name) || name is "." or ".." || name.IndexOfAny(['/', '\\', ':']) >= 0)
            throw new ArgumentException("Nur ein Dateiname ohne Pfad ist zulässig.", nameof(name));
        var path = Path.Combine(root, name);
        RejectLinks(path);
        return path;
    }
}
