#Requires -RunAsAdministrator
param([Parameter(Mandatory)][string]$ServiceDirectory)
$ErrorActionPreference='Stop'
$expected=Join-Path ([Environment]::GetFolderPath('ProgramFiles')) 'AbwesenheitsManager\Service'
$directory=(Resolve-Path -LiteralPath $ServiceDirectory).Path.TrimEnd('\')
if($directory -ne $expected) { throw 'Nur der geschützte Setup-Pfad unter Programme wird unterstützt. Bitte das gemeinsame Setup verwenden.' }
function Assert-Safe([string]$Path) {
    $item=Get-Item -LiteralPath $Path -Force
    if($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Verknüpfung verweigert: $Path" }
    $acl=Get-Acl -LiteralPath $Path
    $trusted=@('S-1-5-18','S-1-5-32-544','S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464')
    if($acl.GetOwner([Security.Principal.SecurityIdentifier]).Value -notin $trusted) { throw "Unsicherer Eigentümer: $Path" }
    $writes=[Security.AccessControl.FileSystemRights]'Write, Delete, DeleteSubdirectoriesAndFiles, ChangePermissions, TakeOwnership'
    foreach($rule in $acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])) {
        if($rule.AccessControlType -eq 'Allow' -and !($rule.PropagationFlags -band [Security.AccessControl.PropagationFlags]::InheritOnly) -and ($rule.FileSystemRights -band $writes) -and $rule.IdentityReference.Value -notin $trusted) { throw "Unsichere Schreibrechte: $Path" }
    }
    if($item.PSIsContainer) { foreach($child in Get-ChildItem -LiteralPath $Path -Force) { Assert-Safe $child.FullName } }
}
for($parent=[IO.DirectoryInfo]$directory; $parent; $parent=$parent.Parent) {
    if($parent.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Verknüpfter Installationspfad.' }
}
Assert-Safe $directory
$exe=Join-Path $directory 'AbwesenheitsManager.Service.exe'
if(!(Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'Service-EXE fehlt.' }
if(Get-Service AbwesenheitsManager -ErrorAction SilentlyContinue) { throw 'Dienst existiert bereits; keine Änderung vorgenommen.' }
# Private ProgramData-Verzeichnisse werden erst durch die Anwendung sicher angelegt.
New-Service -Name AbwesenheitsManager -DisplayName AbwesenheitsManager -BinaryPathName ('"'+$exe+'"') -StartupType Disabled | Out-Null
Write-Host 'Dienst registriert, zunächst deaktiviert. Zum Aktivieren die Einstellungen in der Admin-App speichern.'
