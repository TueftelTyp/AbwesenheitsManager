# Shared by certificate inspection and every Exchange connection. Never repairs imported keys silently.
function Assert-PrivateKeyAcl {
    param([System.Security.AccessControl.FileSecurity]$Acl)
    $trusted=@('S-1-5-18','S-1-5-32-544')
    $descriptor=[Security.AccessControl.RawSecurityDescriptor]::new($Acl.GetSecurityDescriptorBinaryForm(),0)
    if($null -eq $descriptor.DiscretionaryAcl) { throw 'AM_KEY_NULL_DACL' }
    if($Acl.GetOwner([System.Security.Principal.SecurityIdentifier]).Value -notin $trusted) { throw 'AM_KEY_OWNER' }
    foreach($rule in $Acl.GetAccessRules($true,$true,[System.Security.Principal.SecurityIdentifier])) {
        if($rule.AccessControlType -eq 'Allow' -and $rule.IdentityReference.Value -notin $trusted -and
           ($rule.PropagationFlags -band [System.Security.AccessControl.PropagationFlags]::InheritOnly) -eq 0) { throw 'AM_KEY_ACL' }
    }
}
function Assert-CertificateKey {
    param([System.Security.Cryptography.X509Certificates.X509Certificate2]$Certificate)
    $key=[Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($Certificate)
    try {
        $crypto=Join-Path ([Environment]::GetFolderPath('CommonApplicationData')) 'Microsoft\Crypto'
        if($key -is [Security.Cryptography.RSACryptoServiceProvider] -and $key.CspKeyContainerInfo.MachineKeyStore -and !$key.CspKeyContainerInfo.HardwareDevice) {
            $name=$key.CspKeyContainerInfo.UniqueKeyContainerName
            $root=Join-Path $crypto 'RSA\MachineKeys'
        } elseif($key -is [Security.Cryptography.RSACng] -and $key.Key.IsMachineKey -and $key.Key.Provider.Provider -eq 'Microsoft Software Key Storage Provider') {
            $name=$key.Key.UniqueName
            $root=Join-Path $crypto 'Keys'
        } else { throw 'AM_KEY_PROVIDER_UNSUPPORTED' }
        if(!$name -or [IO.Path]::GetFileName($name) -ne $name -or $name.Contains(':')) { throw 'AM_KEY_PATH' }
        $path=Join-Path $root $name
        for($item=$path; $item; $item=Split-Path -Parent $item) {
            if((Get-Item -LiteralPath $item -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'AM_KEY_LINK' }
        }
        Assert-PrivateKeyAcl (Get-Acl -LiteralPath $path)
        $null=$key.SignData([byte[]](1,2,3),[Security.Cryptography.HashAlgorithmName]::SHA256,[Security.Cryptography.RSASignaturePadding]::Pkcs1)
    } finally { if($key) { $key.Dispose() } }
}
