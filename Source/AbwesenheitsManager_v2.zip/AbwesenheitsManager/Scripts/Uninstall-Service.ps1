#Requires -RunAsAdministrator
$ErrorActionPreference='Stop'
$service=Get-Service AbwesenheitsManager -ErrorAction SilentlyContinue
if($service) {
    $base=[Environment]::GetFolderPath('ProgramFiles')
    $allowed=@(('"'+(Join-Path $base 'AbwesenheitsManager\Service\AbwesenheitsManager.Service.exe')+'"'),('"'+(Join-Path $base 'AbwesenheitsManager.ServiceHost\Service\AbwesenheitsManager.Service.exe')+'"'))
    $registered=Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\AbwesenheitsManager'
    if($registered.ImagePath -notin $allowed -or $registered.ObjectName -ne 'LocalSystem') { throw 'Fremde Dienstregistrierung; keine Änderung vorgenommen.' }
    Stop-Service AbwesenheitsManager -ErrorAction Stop
    $service.WaitForStatus('Stopped',[TimeSpan]::FromSeconds(90))
    & sc.exe delete AbwesenheitsManager
    if($LASTEXITCODE -ne 0) { throw 'Dienst konnte nicht entfernt werden.' }
}
Write-Host 'Dienst entfernt. Konfiguration, Logs und Zertifikate bleiben erhalten.'

