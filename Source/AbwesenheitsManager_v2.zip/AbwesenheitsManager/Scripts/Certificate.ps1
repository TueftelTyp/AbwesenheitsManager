param([Parameter(Mandatory)][string]$RequestPath,[Parameter(Mandatory)][string]$ResponsePath)
$ErrorActionPreference='Stop'
$env:PSModulePath=(Join-Path $PSHOME 'Modules')+';'+(Join-Path ([Environment]::GetFolderPath('ProgramFiles')) 'PowerShell\Modules')+';'+(Join-Path ([Environment]::GetFolderPath('System')) 'WindowsPowerShell\v1.0\Modules')
try {
    . (Join-Path $PSScriptRoot 'Key-Security.ps1')
    $r=Get-Content -LiteralPath $RequestPath -Raw | ConvertFrom-Json
    if($r.Mode -eq 'Create') {
        $cert=New-SelfSignedCertificate -Subject 'CN=AbwesenheitsManager' -CertStoreLocation 'Cert:\LocalMachine\My' -Provider 'Microsoft Enhanced RSA and AES Cryptographic Provider' -KeySpec Signature -KeyLength 2048 -HashAlgorithm SHA256 -KeyExportPolicy NonExportable -NotAfter (Get-Date).AddYears(1)
    } elseif($r.Mode -eq 'Inspect') {
        $thumb=$r.Thumbprint -replace '\s',''
        if($thumb -notmatch '^[A-Fa-f0-9]{40}$') { throw 'Ungültiger Thumbprint.' }
        $cert=Get-Item -LiteralPath "Cert:\LocalMachine\My\$thumb"
    } else { throw 'Unbekannter Zertifikatmodus.' }
    Assert-CertificateKey $cert
    @{Thumbprint=$cert.Thumbprint;Subject=$cert.Subject;NotBefore=$cert.NotBefore;NotAfter=$cert.NotAfter;HasPrivateKey=$cert.HasPrivateKey;PublicBase64=[Convert]::ToBase64String($cert.Export([Security.Cryptography.X509Certificates.X509ContentType]::Cert))} | ConvertTo-Json | Set-Content -LiteralPath $ResponsePath -Encoding utf8
} catch { [Console]::Error.WriteLine("AM_OPERATION_FAILED"); exit 1 }

