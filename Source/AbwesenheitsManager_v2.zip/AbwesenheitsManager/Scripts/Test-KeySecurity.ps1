$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Key-Security.ps1')
$acl=[Security.AccessControl.FileSecurity]::new()
$acl.SetSecurityDescriptorSddlForm('O:BAG:BAD:P(A;;FA;;;SY)(A;;FA;;;BA)')
Assert-PrivateKeyAcl $acl
$passed=1
foreach($sid in @('BU','AU','WD')) {
    $acl.SetSecurityDescriptorSddlForm("O:BAG:BAD:P(A;;FA;;;SY)(A;;FA;;;BA)(A;;FR;;;$sid)")
    $rejected=$false
    try { Assert-PrivateKeyAcl $acl } catch { $rejected=$true }
    if(!$rejected) { throw "Unsichere Schlüsselrechte akzeptiert: $sid" }
    $passed++
}
$acl.SetSecurityDescriptorSddlForm('O:BUG:BAD:P(A;;FA;;;SY)(A;;FA;;;BA)')
$rejected=$false
try { Assert-PrivateKeyAcl $acl } catch { $rejected=$true }
if(!$rejected) { throw 'Unsicherer Besitzer akzeptiert' }
$passed++
Write-Output "$passed Schlüssel-ACL-Tests erfolgreich (synthetische ACLs, keine Zertifikate verändert)."
