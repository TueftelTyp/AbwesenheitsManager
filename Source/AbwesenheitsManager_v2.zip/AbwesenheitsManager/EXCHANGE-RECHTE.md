# Exchange-Berechtigungen vor dem Produktivbetrieb

Die lokale Sicherheitsprüfung ersetzt keine Prüfung im Tenant. Das Setup verändert keine Entra- oder Exchange-Berechtigungen. Die Anwendung verwendet Exchange Online PowerShell.

## Zielzustand

Die App erhält `Exchange.ManageAsApp` mit Administratorzustimmung und eine benutzerdefinierte Exchange-Rollengruppe über ihren Service Principal. Die Rollen sollen ausschließlich die benötigten Cmdlets und Parameter enthalten; ein Empfänger-Schreibbereich begrenzt die Zielpostfächer. Breite Entra-Rollen wie Exchange Administrator dürfen nicht parallel bestehen bleiben, weil Berechtigungen aus mehreren Zuweisungen zusammenwirken.

Microsoft beschreibt diesen Weg unter [App-only-Authentifizierung, Schritt 5, Option 2](https://learn.microsoft.com/powershell/exchange/app-only-auth-powershell-v2#step-5-assign-role-permissions-to-the-application). Graph-/EWS-Anwendungsrollen und ApplicationAccessPolicy ersetzen die benötigten PowerShell-Verwaltungsrollen nicht.

## Vorgehen durch den Tenant-Administrator

1. App-ID und die Objekt-ID der **Enterprise Application** ermitteln. Die Objekt-ID der App-Registrierung ist eine andere ID.
2. Bestehende Entra-Rollenzuweisungen und Exchange-Rollengruppenmitgliedschaften der Anwendung inventarisieren. Auch indirekte/breite Zuweisungen prüfen.
3. Aus geeigneten vorhandenen Exchange-Verwaltungsrollen eigene Rollen ableiten. Nur die Einträge für `Get-EXOMailbox`, `Get-MailboxAutoReplyConfiguration` und `Set-MailboxAutoReplyConfiguration` behalten. Die Zuordnung der REST-Lese-Cmdlets zu Rollen im Tenant prüfen. Beim Set-Cmdlet nur `Identity`, `InternalMessage`, `ExternalMessage` und notwendige gemeinsame Parameter zulassen; insbesondere keine Zeitplan-/Statusparameter hinzufügen.
4. Einen geprüften Empfängerfilter für die verwalteten Postfächer als Schreibbereich verwenden und über die Rollenzuweisungen der eigenen Rollengruppe anwenden. Ein Schreibbereich beschränkt nicht automatisch die Lesesicht. Wenn auch Lesen eingeschränkt werden muss, dies gesondert prüfen. Die lokale Ausschlussliste ist keine Berechtigungsgrenze.
5. Den Service Principal bei Bedarf in Exchange registrieren und der geprüften Rollengruppe hinzufügen. Breite Entra-Rollen nach erfolgreicher Vorbereitung entfernen. Eine neue Sitzung öffnen, damit keine alten Rollen im Sitzungstoken weiterwirken.
6. Mit genau dem App-Zertifikat testen: Lesen, Dry-Run und anschließend eine kontrollierte Änderung innerhalb des Pilotbereichs. Außerhalb des Schreibbereichs muss ein bewusst autorisierter Test verweigert werden. Ein erfolgreiches `Get-Command` allein beweist keine eingeschränkten Schreibrechte.

Vorlage für die Zuordnung, erst nach Erstellung und Prüfung der Rollengruppe ausführen:

```powershell
# Bereits als berechtigter Tenant-Administrator mit Exchange verbunden.
# Platzhalter vor Ausführung ersetzen. Diese Befehle ändern den Tenant.
New-ServicePrincipal -AppId '<Client-ID>' -ObjectId '<Enterprise-App-Object-ID>' -DisplayName 'AbwesenheitsManager'
$sp = Get-ServicePrincipal -Identity '<Enterprise-App-Object-ID>'
Add-RoleGroupMember -Identity '<Geprüfte-eigene-Rollengruppe>' -Member $sp.Identity
```

Kein pauschales Skript entfernt automatisch bestehende Rollen: Ohne Kenntnis der gemeinsamen Nutzung der App wäre das ein möglicher Betriebsausfall. Die tatsächlich wirksamen Rechte und der Negativtest sind vor Produktivfreigabe durch den Tenant-Administrator zu dokumentieren.
