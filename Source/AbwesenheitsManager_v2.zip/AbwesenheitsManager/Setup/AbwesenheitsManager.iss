; Build after Scripts/Publish.ps1 with Inno Setup 6 (ISCC.exe).
[Setup]
AppId={{463A2FCB-39DC-46AC-A671-18D04B3A14CF}
AppName=AbwesenheitsManager
AppVersion=1.5.0
DefaultDirName={autopf}\AbwesenheitsManager
DisableDirPage=yes
UsePreviousAppDir=no
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
DefaultGroupName=AbwesenheitsManager
UninstallDisplayIcon={app}\Admin\AbwesenheitsManager.Admin.exe
SetupIconFile=..\Assets\icon.ico
OutputDir=..\setup-output
OutputBaseFilename=AbwesenheitsManager-Setup
Compression=lzma2
SolidCompression=yes
CloseApplications=yes
RestartApplications=no

[Files]
Source: "..\publish\Admin\*"; DestDir: "{app}\Admin"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\publish\Service\*"; DestDir: "{app}\Service"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\publish\Tray\*"; DestDir: "{app}\Tray"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "Maintenance.ps1"; DestDir: "{app}\Setup"; Flags: ignoreversion
Source: "Maintenance.ps1"; Flags: dontcopy

[Icons]
Name: "{group}\AbwesenheitsManager"; Filename: "{app}\Admin\AbwesenheitsManager.Admin.exe"

[Code]
function RunMaintenance(Script: String; Mode: String): Boolean;
var
  ExitCode: Integer;
begin
  Result := Exec(ExpandConstant('{sys}\WindowsPowerShell\v1.0\powershell.exe'),
    '-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' + Script + '" -Mode ' + Mode,
    '', SW_HIDE, ewWaitUntilTerminated, ExitCode);
  Result := Result and (ExitCode = 0);
end;

function PrepareToInstall(var NeedsRestart: Boolean): String;
begin
  ExtractTemporaryFile('Maintenance.ps1');
  if not RunMaintenance(ExpandConstant('{tmp}\Maintenance.ps1'), 'Upgrade') then
    Result := 'Vorbereitung fehlgeschlagen. Admin-Fenster schließen und erneut versuchen. Details: %ProgramFiles%\AbwesenheitsManager-maintenance.log';
end;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if CurUninstallStep = usUninstall then begin
    if not RunMaintenance(ExpandConstant('{app}\Setup\Maintenance.ps1'), 'Uninstall') then
      RaiseException('Bereinigung fehlgeschlagen. Admin-Fenster schließen und Deinstallation erneut ausführen. Details: %ProgramFiles%\AbwesenheitsManager-maintenance.log');
  end;
end;

