#Requires -Version 5.1
#Requires -RunAsAdministrator
param([ValidateSet('Upgrade','Uninstall')][string]$Mode='Uninstall')
$ErrorActionPreference='Stop'
$programFiles=[Environment]::GetFolderPath('ProgramFiles')
$appRoot=Join-Path $programFiles 'AbwesenheitsManager'
$legacyRoot=Join-Path $programFiles 'AbwesenheitsManager.ServiceHost'
$dataRoot=Join-Path ([Environment]::GetFolderPath('CommonApplicationData')) 'AbwesenheitsManager'
$statusRoot=$dataRoot+'.Status'
$logPath=Join-Path $programFiles 'AbwesenheitsManager-maintenance.log'

function Assert-Protected([string]$Path) {
    $trusted=@('S-1-5-18','S-1-5-32-544','S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464')
    $acl=Get-Acl -LiteralPath $Path
    if($acl.GetOwner([Security.Principal.SecurityIdentifier]).Value -notin $trusted) { throw "Unsicherer Eigentümer: $Path" }
    $writeRights=[Security.AccessControl.FileSystemRights]'Write, Delete, DeleteSubdirectoriesAndFiles, ChangePermissions, TakeOwnership'
    foreach($rule in $acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])) {
        if($rule.AccessControlType -eq 'Allow' -and !($rule.PropagationFlags -band [Security.AccessControl.PropagationFlags]::InheritOnly) -and ($rule.FileSystemRights -band $writeRights) -and $rule.IdentityReference.Value -notin $trusted) {
            throw "Unsichere Schreibrechte: $Path"
        }
    }
}

function Assert-NoLinks([string]$Path) {
    if(!(Test-Path -LiteralPath $Path)) { return }
    $item=Get-Item -LiteralPath $Path -Force -ErrorAction Stop
    if($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Verknüpfung nicht zulässig: $Path" }
    Assert-Protected $Path
    if($item.PSIsContainer) {
        foreach($child in Get-ChildItem -LiteralPath $Path -Force) { Assert-NoLinks $child.FullName }
    }
}
function Remove-OwnedDirectory([string]$Path) {
    $resolved=[IO.Path]::GetFullPath($Path).TrimEnd('\')
    if($resolved -notin @($legacyRoot,$dataRoot,$statusRoot)) { throw "Unzulässiges Löschziel: $resolved" }
    if(Test-Path -LiteralPath $resolved) {
        for($parent=[IO.DirectoryInfo](Split-Path $resolved -Parent); $parent; $parent=$parent.Parent) {
            if($parent.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Verknüpfter übergeordneter Löschpfad.' }
        }
        Assert-NoLinks $resolved
        Remove-Item -LiteralPath $resolved -Recurse -Force
    }
}
function Remove-UserSettings([string]$Hive) {
    $run="Registry::HKEY_USERS\$Hive\Software\Microsoft\Windows\CurrentVersion\Run"
    if(Test-Path -LiteralPath $run) {
        if(Get-ItemProperty -LiteralPath $run -Name 'AbwesenheitsManager.Tray' -ErrorAction SilentlyContinue) {
            Remove-ItemProperty -LiteralPath $run -Name 'AbwesenheitsManager.Tray' -ErrorAction Stop
        }
    }
    $preferences="Registry::HKEY_USERS\$Hive\Software\AbwesenheitsManager"
    if(Test-Path -LiteralPath $preferences) {
        # Never recursively delete a user-controlled registry tree as administrator.
        if(Get-ItemProperty -LiteralPath $preferences -Name 'TrayAutostartConfigured' -ErrorAction SilentlyContinue) {
            Remove-ItemProperty -LiteralPath $preferences -Name 'TrayAutostartConfigured' -ErrorAction Stop
        }
    }
}
try {
    # Do not force-close Admin: a manual Exchange run or unsaved settings could be active.
    if(Get-Process -Name AbwesenheitsManager.Admin -ErrorAction SilentlyContinue) {
        throw 'Admin-Fenster zuerst schließen und laufende Aktionen beenden.'
    }
    foreach($tray in Get-Process -Name AbwesenheitsManager.Tray -ErrorAction SilentlyContinue) {
        if([string]::Equals($tray.Path,(Join-Path $appRoot 'Tray\AbwesenheitsManager.Tray.exe'),[StringComparison]::OrdinalIgnoreCase)) {
            Stop-Process -Id $tray.Id -Force -ErrorAction Stop
        }
    }
    $service=Get-Service -Name AbwesenheitsManager -ErrorAction SilentlyContinue
    if($service) {
        $registration=Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\AbwesenheitsManager'
        $expected=@(('"'+(Join-Path $appRoot 'Service\AbwesenheitsManager.Service.exe')+'"'),('"'+(Join-Path $legacyRoot 'Service\AbwesenheitsManager.Service.exe')+'"'))
        if($registration.ImagePath -notin $expected -or $registration.ObjectName -ne 'LocalSystem') {
            throw 'Gleichnamiger Dienst gehört nicht zur erwarteten Installation. Abbruch ohne Dienständerung.'
        }
        Set-Service -Name AbwesenheitsManager -StartupType Disabled
        if($service.Status -ne 'Stopped') { Stop-Service -Name AbwesenheitsManager -ErrorAction Stop }
        $service.WaitForStatus('Stopped',[TimeSpan]::FromSeconds(90))
        $service.Dispose()
        & "$env:SystemRoot\System32\sc.exe" delete AbwesenheitsManager | Out-Null
        if($LASTEXITCODE -ne 0) { throw 'Dienst konnte nicht gelöscht werden.' }
        if(Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Services\AbwesenheitsManager') {
            throw 'Dienst ist zur Löschung vorgemerkt. Dienste-Verwaltung schließen oder Windows neu starten und erneut versuchen.'
        }
    }
    Remove-OwnedDirectory $legacyRoot
    if($Mode -eq 'Uninstall') {
        # Loaded and unloaded local profiles, including the original non-admin account.
        $profiles=Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList\*'
        foreach($profile in $profiles) {
            $sid=$profile.PSChildName
            if($sid -notmatch '^S-1-(5-21|12-1)-') { continue }
            if(Test-Path "Registry::HKEY_USERS\$sid") { Remove-UserSettings $sid; continue }
            $hiveFile=Join-Path ([Environment]::ExpandEnvironmentVariables($profile.ProfileImagePath)) 'NTUSER.DAT'
            if(!(Test-Path -LiteralPath $hiveFile)) { continue }
            for($entry=Get-Item -LiteralPath $hiveFile -Force; $entry; $entry=Get-Item -LiteralPath (Split-Path $entry.FullName -Parent) -Force -ErrorAction SilentlyContinue) {
                if($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Verknüpftes Benutzerprofil: $sid" }
                if($entry.FullName.TrimEnd('\') -eq [IO.Path]::GetPathRoot($entry.FullName).TrimEnd('\')) { break }
            }
            $mount='AbwesenheitsManager_Uninstall_'+[Guid]::NewGuid().ToString('N')
            & "$env:SystemRoot\System32\reg.exe" load "HKU\$mount" $hiveFile | Out-Null
            if($LASTEXITCODE -ne 0) { throw "Benutzerprofil nicht zugänglich: $sid" }
            try { Remove-UserSettings $mount }
            finally {
                [GC]::Collect(); [GC]::WaitForPendingFinalizers()
                & "$env:SystemRoot\System32\reg.exe" unload "HKU\$mount" | Out-Null
                if($LASTEXITCODE -ne 0) { throw "Benutzerprofil konnte nicht entladen werden: $sid" }
            }
        }
        Remove-OwnedDirectory $dataRoot
        Remove-OwnedDirectory $statusRoot
    }
    if(Test-Path -LiteralPath $logPath) { Assert-NoLinks $logPath; Remove-Item -LiteralPath $logPath -Force }
    exit 0
} catch {
    $failure=$_ | Out-String
    Assert-Protected $programFiles
    if(Test-Path -LiteralPath $logPath) { Assert-NoLinks $logPath }
    $failure | Set-Content -LiteralPath $logPath -Encoding UTF8
    exit 1
}
