# Prüfstand – Tray-Erweiterung (.NET 9)

Stand: 22.10.2026. Ausgangsbasis: AbwesenheitsManager-net9-Hilfebutton.zip vom 30.09.2026.

## Erfolgreich geprüft vor der Icon-Anpassung

- Release-Build der vollständigen Solution mit .NET SDK 9.0.318: 0 Fehler, 0 Warnungen, alle sechs Projekte auf net9.0-windows.
- 32 C#-Tests bestanden: bisherige 23 Tests einschließlich DPAPI sowie 9 neue Statusprüfungen (grün, Warnung, Fehlerpriorität, fehlende/veraltete/zukünftige Daten, laufende Prüfung, datensparsames Statusformat und JSON-Roundtrip).
- 10 PowerShell-Schutztests bestanden; keine Verbindung zu Exchange hergestellt.
- Handbuch aus aktualisierter README neu generiert und beim Build mitkopiert.
- Tray besitzt keine Service-Stop-/Start-Funktion; Beenden verlässt nur den eigenen Anwendungskontext und gibt Timer/Icon-Ressourcen frei.
- Das neue Statusformat enthält keine SMTP-Zugangsdaten, Postfachadressen oder Fehlertexte. Die bestehende ProgramData-Konfiguration und deren ACL bleiben unverändert.
- Runner, SMTP-, Zertifikats-, Exchange- und Vorlagenlogik wurden nicht verändert.

## Grenzen der Prüfung

Kein produktiver Dienst installiert oder gestartet; kein Benutzerautostart auf diesem Rechner gesetzt. Anmeldung, UAC, Tray-Interaktion und Statusordner-Berechtigungen müssen auf dem Zielhost mit Administrator- und Standardbenutzerkonto abgenommen werden. Kein Live-Test gegen Exchange oder SMTP. Kein Self-contained-Publish und kein interaktiver Visual-Studio-Test in dieser Sitzung.

## Abnahme auf dem Zielhost

1. Scripts/Publish.ps1 ausführen, Admin/Service/Tray als benachbarte Ordner in einem festen, administrativ geschützten Installationspfad bereitstellen.
2. Aktualisierten Dienst installieren/neu starten. Als Standardbenutzer prüfen, dass nur der Statusordner lesbar ist und Einstellungen/SMTP-Daten geschützt bleiben.
3. Tray starten; Dienststatus, Zeitplan aus/ein sowie letzte/nächste Prüfung prüfen. Fehlender Dienst und fehlende/veraltete Statusdatei müssen rot bzw. grau erscheinen.
4. Doppelklick und Jetzt prüfen testen, auch mit abgelehnter UAC-Abfrage. Jetzt prüfen öffnet nur die manuelle Auswahl; bestehende Runner-Sperre bleibt wirksam.
5. Autostart im gewünschten Benutzerkonto aktivieren, ab-/anmelden; nur ein Tray-Symbol. Autostart deaktivieren und Anmeldung wiederholen. Bei anderer UAC-Identität das Benutzerskript verwenden.
6. Beenden wählen und im Dienste-Manager kontrollieren, dass der Dienst weiterläuft.

Das ZIP enthält den vollständigen Quellstand einschließlich Handbuch, Tests und Publish-Skripten, ohne bin/obj oder produktive Konfiguration.

## Nachtrag: eigenes Icon und Programmname

ICO und PNG unverändert übernommen; Ressourcenverweise und Projekt-/XAML-XML geprüft. Fenstertitel und Produktmetadaten lauten AbwesenheitsManager. Tray verwendet das eigene Icon mit Statusmarkierungen. Der erneute Build nach diesen Anpassungen wurde durch fehlenden Zugriff auf AppData/Local/Microsoft SDKs blockiert; deshalb ist der Build dieses Nachtrags noch nicht bestätigt. Die oben genannten erfolgreichen Build-/Testergebnisse betreffen die vorherige Tray-Fassung.


## Nachtrag: Hilfebutton im Kopfbereich

Hilfebutton nach links oben in den blauen Kopfbereich vor das Programmicon verschoben. Click-Handler und F1 bleiben erhalten. README und Handbuch angepasst; XAML als XML geprüft, genau ein HelpButton vorhanden. Kein erneuter Build bestätigt (weiterhin eingeschränkter Windows-SDK-Zugriff).


Aktueller Stand: Hilfebutton rechts oben im blauen Kopfbereich angedockt, mit Abstand zum Titel. Click-Handler und F1 unverändert. XAML-Struktur und genau ein rechts angedockter HelpButton geprüft; README/Handbuch aktualisiert. Kein erneuter Build bestätigt.

## Neuer Stand: automatischer Lebenszyklus und Setup-Vorlage

- Einstellungen speichern richtet bei aktiviertem Zeitplan den Dienst ein und startet ihn.
- Deaktivieren schreibt zuerst SchedulerEnabled=false, setzt den Dienst auf Disabled und wartet nach Stop auf Stopped. Fehlgeschlagene Dienstaktionen werden angezeigt.
- Manuelle Läufe ändern den gespeicherten Dienstzustand nicht mehr; sie verwenden die eingegebenen Werte ohne Speicherung.
- Beim Schließen startet das Tray; solange Admin in derselben Sitzung läuft, wird das Symbol ausgeblendet. Bei Windows-Abmeldung wird kein Tray neu gestartet.
- Absichtlich deaktivierter Dienst erscheint als Inaktiv (grau).
- Inno-Setup-Quellvorlage und Build-Skript ergänzt. Bereinigung umfasst Dienst, alte ServiceHost-Kopie, Autostarts in lokalen Benutzerprofilen und bei Deinstallation lokale Einstellungen/Logs. Zertifikate und externe Ressourcen bleiben erhalten.
- PowerShell-Syntax und Projekt-/XAML-XML geprüft. 10 bestehende PowerShell-Schutztests erneut bestanden.
- Neuer C#-Build nicht möglich: Zugriff auf AppData/Local/Microsoft SDKs verweigert. Keine aktuellen C#-Testergebnisse. Inno Setup ist nicht installiert; Setup wurde nicht kompiliert. Es wurden keine Dienste, Autostarts oder Installationen auf diesem Rechner geändert.
- Vor Freigabe auf einem Testrechner prüfen: Erstinstallation, Speichern ein/aus, Neustart, aktiver Lauf beim Stop, Abmeldung, UAC-Kontowechsel, Update, Deinstallation mit geladenen/ungeladenen Benutzerprofilen und Fehlerfällen. Setup-Vorlage ist noch keine freigegebene Installationsdatei.

## Sicherheitsstand vom 23.10.2026

Siehe SECURITY-REVIEW.md. SMTP-TLS-Prüfung, Datei-/Verzeichnisschutz, PowerShell-Modulsuche, Tray-Privilegien und Deinstallationsschutz wurden gehärtet. Vollständiger Release-Build: 0 Fehler/Warnungen; 44 C#-Tests und 10 PowerShell-Schutztests bestanden. Build nutzte die explizite Windows-7.0-Plattformkennung für das unveränderte TargetFramework net9.0-windows. NuGet-Audit und Windows-Integrationstests sind nicht bestätigt; Details und geänderte Betriebsvoraussetzungen im Sicherheitsbericht. Frühere Build-Einschränkungen in diesem Dokument beschreiben historische Stände.
