using AbwesenheitsManager.Core;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using AbwesenheitsManager.Admin;
static class Program
{
[STAThread]
static void Main(string[] args)
{
if(args.Length==2 && args[0]=="--render")
{
    var app=new App(); app.InitializeComponent();
    var window=new MainWindow(new Settings());
    var content=(FrameworkElement)window.Content;
    content.Measure(new Size(1180,820)); content.Arrange(new Rect(0,0,1180,820)); content.UpdateLayout();
    var image=new RenderTargetBitmap(1180,820,96,96,PixelFormats.Pbgra32); image.Render(content);
    var encoder=new PngBitmapEncoder(); encoder.Frames.Add(BitmapFrame.Create(image));
    using var file=File.Create(args[1]); encoder.Save(file);
    Console.WriteLine("WPF-Oberfläche erfolgreich instanziiert und gerendert."); return;
}
var passed=0;
void Check(string name,bool result) { if(!result) throw new Exception("FAIL: "+name); Console.WriteLine("PASS: "+name); passed++; }
void Reject(string name,Action action) { try { action(); } catch(ArgumentException) { Check(name,true); return; } throw new Exception("FAIL: "+name); }
var now = DateTimeOffset.UtcNow;
var status = new TraySnapshot(now, now.AddMinutes(-5), now.AddMinutes(5), true, false, 0, 0);
Check("Tray: erfolgreich grün", TraySupport.EvaluateSnapshot(status, now) == "Läuft");
Check("Tray: Warnung gelb", TraySupport.EvaluateSnapshot(status with { Warnings = 1 }, now).StartsWith("Warnung"));
Check("Tray: Fehler hat Vorrang", TraySupport.EvaluateSnapshot(status with { Warnings = 1, Errors = 1 }, now).StartsWith("Fehler"));
Check("Tray: fehlender Status unbekannt", TraySupport.EvaluateSnapshot(null, now).StartsWith("Unbekannt"));
Check("Tray: veralteter Status unbekannt", TraySupport.EvaluateSnapshot(status with { Updated = now.AddSeconds(-91) }, now).StartsWith("Unbekannt"));
Check("Tray: Zukunftsstatus unbekannt", TraySupport.EvaluateSnapshot(status with { Updated = now.AddMinutes(1) }, now).StartsWith("Unbekannt"));
Check("Tray: laufende Prüfung bleibt frisch", TraySupport.EvaluateSnapshot(status with { Running = true }, now) == "Läuft");
var publicJson = System.Text.Json.JsonSerializer.Serialize(status, Storage.Json);
Check("Tray: Status ohne Geheimnisse und Postfächer", !publicJson.Contains("Smtp") && !publicJson.Contains("Tenant") && !publicJson.Contains("Identity"));
Check("Tray: Status JSON roundtrip", System.Text.Json.JsonSerializer.Deserialize<TraySnapshot>(publicJson, Storage.Json) == status);
var s=new Settings(); Templates.Validate(s);
Reject("SMTP-Test ohne TLS verweigert auch bei deaktivierten Meldungen", () => SmtpNotifier.ValidateTransport(new SmtpSettings { Enabled=false, StartTls=false, Username="user", ProtectedPassword="secret" }));
SmtpNotifier.ValidateTransport(new SmtpSettings { StartTls=false, Username="" });
Check("SMTP-Relay ohne Anmeldung bleibt erlaubt", true);
SmtpNotifier.ValidateTransport(new SmtpSettings { StartTls=true, Username="user" });
Check("SMTP-Anmeldung mit TLS bleibt erlaubt", true);
foreach (var invalid in new[] { "../settings.json", @"..\settings.json", @"C:\settings.json", "settings.json:stream", "..", "" })
    Reject("Datenpfad verweigert: " + invalid, () => SafePaths.DataFile(Path.GetTempPath(), invalid));
Check("Lokaler Dateiname zulässig", SafePaths.DataFile(Path.GetTempPath(), "settings.json") == Path.Combine(Path.GetTempPath(), "settings.json"));
Reject("Übergroße HTML-Nachricht verweigert", () => Templates.Canonical(new string('x', 1_048_577)));
Reject("Übermäßig verschachteltes HTML verweigert", () => Templates.Canonical(string.Concat(Enumerable.Repeat("<div>", 130)) + "Text" + string.Concat(Enumerable.Repeat("</div>", 130))));
Check("Standardvorlage mit unveränderten Platzhaltern",Templates.Matches(s.InternalHtml,s.InternalHtml,s.Variables));
var filled=s.InternalHtml.Replace("[Datum]","31.10.2026").Replace("[Vertretung]","Erika Muster").Replace("[E-Mail-Adresse]","erika@example.org").Replace("[Telefonnummer]","+49 123 456");
Check("Nur Variablen geändert",Templates.Matches(filled,s.InternalHtml,s.Variables));
Check("Fester Text geändert",!Templates.Matches(filled.Replace("Vielen Dank","Danke"),s.InternalHtml,s.Variables));
Check("Regex greift",!Templates.Matches(filled.Replace("erika@example.org","keine Adresse"),s.InternalHtml,s.Variables));
Check("Kein HTML im Variablenbereich",!Templates.Matches(filled.Replace("Erika Muster","<i>Erika Muster</i>"),s.InternalHtml,s.Variables));
Check("Entities äquivalent",Templates.Matches(filled.Replace("Erika Muster","Erika &amp; Max"),s.InternalHtml,s.Variables));
Check("Aktiv wird übersprungen",Templates.Plan(new("x@example.org","Enabled","falsch","falsch"),s) is null);
Check("Geplant wird übersprungen",Templates.Plan(new("x@example.org","Scheduled","falsch","falsch"),s) is null);
Check("Unbekannter Status wird übersprungen",Templates.Plan(new("x@example.org","Unexpected","falsch","falsch"),s) is null);
s.ExcludedMailboxes.Add("X@example.org");
Check("Ausschluss ohne Beachtung der Großschreibung",Templates.Plan(new("x@example.org","Disabled","falsch","falsch"),s) is null); s.ExcludedMailboxes.Clear();
var change=Templates.Plan(new("x@example.org","Disabled",filled,"falsch"),s)!;
Check("Nur externe Seite korrigiert",change.InternalHtml is null && change.ExternalHtml==s.ExternalHtml);
Check("Gültige Variablen bleiben erhalten",Templates.Plan(new("x@example.org","Disabled",filled,filled),s) is null);
Check("Leere Antwort wird initialisiert",Templates.Plan(new("x@example.org","Disabled","",""),s) is not null);
Check("Wrapper normalisiert",Templates.Matches("<html><head><meta charset='utf-8'></head><body><p>Test</p></body></html>","<p>Test</p>",[]));
Check("Feste Attribute geschützt",!Templates.Matches("<p style='color:red'>Test</p>","<p>Test</p>",[]));
var repeat=new List<Variable> { new() { Name="X",Placeholder="[X]" } };
Check("Wiederholte Variable konsistent",Templates.Matches("<p>A / A</p>","<p>[X] / [X]</p>",repeat));
Check("Wiederholte Variable inkonsistent",!Templates.Matches("<p>A / B</p>","<p>[X] / [X]</p>",repeat));
Reject("Ungültige Regex",()=>Templates.Validate(new Settings { Variables=[new(){Name="X",Placeholder="[X]",ValidationPattern="("}] }));
Reject("Doppelte Platzhalter",()=>Templates.Validate(new Settings { Variables=[new(){Name="A",Placeholder="[X]"},new(){Name="B",Placeholder="[X]"}] }));
Reject("Benachbarte Platzhalter",()=>Templates.Validate(new Settings {InternalHtml="[A][B]",Variables=[new(){Name="A",Placeholder="[A]"},new(){Name="B",Placeholder="[B]"}] }));
Reject("Platzhalter in Attribut",()=>Templates.Validate(new Settings {InternalHtml="<a href='[Datum]'>Link</a>"}));
Reject("Ungültiges Intervall",()=>Templates.Validate(new Settings {IntervalMinutes=0}));
Reject("Zu viele Variablen",()=>Templates.Validate(new Settings { Variables=Enumerable.Range(0,65).Select(i=>new Variable {Name="X",Placeholder="["+i+"]"}).ToList() }));
Reject("Zu lange Regex",()=>Templates.Matches("x","x",[new() {Name="X",Placeholder="[X]",ValidationPattern=new string('a',2049)}]));
Reject("Leerer Platzhalter auch ohne Validate",()=>Templates.Matches("x","x",[new() {Name="X",Placeholder=""}]));
Reject("Vorlage vor Traversierung begrenzt",()=>Templates.Validate(new Settings {InternalHtml=new string('x',1_048_577)}));
Check("Regex-Syntax im Platzhalter bleibt literal",Templates.Matches("<p>Wert</p>","<p>[.*]</p>",[new(){Name="X",Placeholder="[.*]"}]));
var acl=new System.Security.AccessControl.FileSecurity();
acl.SetSecurityDescriptorSddlForm("O:BAG:BAD:P(A;;FA;;;SY)(A;;FA;;;BA)(A;;FR;;;BU)");
SafePaths.ValidateAcl(acl);
try { SafePaths.ValidateAcl(acl,true); throw new Exception("Öffentliche Leserechte akzeptiert"); }
catch(UnauthorizedAccessException) { Check("Geheimnisdatei verweigert explizite Benutzer-Leserechte",true); }
acl.SetSecurityDescriptorSddlForm("O:BAG:BAD:P(A;;FA;;;SY)(A;;FA;;;BA)");
SafePaths.ValidateAcl(acl,true); Check("Private System/Admin ACL zulässig",true);
acl.SetSecurityDescriptorSddlForm("O:BAG:BAD:P(A;;FA;;;SY)(A;;FA;;;BA)(A;;FW;;;BU)");
try { SafePaths.ValidateAcl(acl); throw new Exception("Schreibrechte akzeptiert"); }
catch(UnauthorizedAccessException) { Check("Öffentliche Statusdatei verweigert Benutzer-Schreibrechte",true); }
Check("Externe Ausnahme wird nicht veröffentlicht",!SafeDiagnostics.Describe(new Exception("SECRET-TOKEN" )).Contains("SECRET-TOKEN"));
var report=SmtpNotifier.Report(new RunSummary {Errors=["SECRET-TOKEN"],Warnings=["PRIVATE-BODY"],Results=[new("private@example.org","Error","PASSWORD")]});
Check("SMTP-Bericht enthält keine Freitexte",!report.Contains("SECRET") && !report.Contains("PRIVATE") && !report.Contains("PASSWORD") && !report.Contains("private@"));
var scriptDir=Path.Combine(Path.GetTempPath(),"AM-integrity-"+Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(scriptDir);
try {
    foreach(var f in Directory.GetFiles(Path.Combine(AppContext.BaseDirectory,"Scripts"),"*.ps1")) File.Copy(f,Path.Combine(scriptDir,Path.GetFileName(f)));
    AbwesenheitsManager.Exchange.ScriptIntegrity.Verify(scriptDir); Check("Ausgelieferte Skripte entsprechen Referenz",true);
    File.AppendAllText(Path.Combine(scriptDir,"Key-Security.ps1"),"#changed");
    try { AbwesenheitsManager.Exchange.ScriptIntegrity.Verify(scriptDir); throw new Exception("Manipulation akzeptiert"); }
    catch(UnauthorizedAccessException) { Check("Skriptmanipulation verweigert",true); }
} finally { foreach(var f in Directory.GetFiles(scriptDir)) File.Delete(f); Directory.Delete(scriptDir); }
var secret=Storage.Protect("Test-Passwort-äöü"); Check("DPAPI LocalMachine roundtrip",Storage.Unprotect(secret)=="Test-Passwort-äöü");
Console.WriteLine($"{passed} Tests erfolgreich.");
}
}
