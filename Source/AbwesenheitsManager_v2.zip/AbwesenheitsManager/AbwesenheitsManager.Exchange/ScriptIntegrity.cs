using System.Security.Cryptography;

namespace AbwesenheitsManager.Exchange;

public static class ScriptIntegrity
{
    public static void Verify(string directory)
    {
        foreach (var name in new[] { "Exchange.ps1", "Certificate.ps1", "Apply-Changes.ps1", "Key-Security.ps1" })
        {
            using var trusted = typeof(ScriptIntegrity).Assembly.GetManifestResourceStream("TrustedScripts." + name)
                ?? throw new InvalidDataException("Skriptreferenz fehlt.");
            using var actual = File.OpenRead(Path.Combine(directory, name));
            if (!CryptographicOperations.FixedTimeEquals(SHA256.HashData(trusted), SHA256.HashData(actual)))
                throw new UnauthorizedAccessException("Skriptintegrität verletzt; Anwendung aus vertrauenswürdigem Setup neu installieren.");
        }
    }
}
