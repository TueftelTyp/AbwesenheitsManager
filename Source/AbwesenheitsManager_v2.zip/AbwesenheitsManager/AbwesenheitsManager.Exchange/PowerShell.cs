using System.Diagnostics;
using System.Text;
using System.Text.Json;
using AbwesenheitsManager.Core;
namespace AbwesenheitsManager.Exchange;
public static class PowerShell
{
    public static async Task<T> Execute<T>(Settings settings,string script,object request,CancellationToken token)
    {
        if (script is not ("Exchange.ps1" or "Certificate.ps1")) throw new ArgumentException("Unzulässiges Skript.", nameof(script));
        if (!Path.IsPathFullyQualified(settings.PowerShellPath) || !string.Equals(Path.GetFileName(settings.PowerShellPath), "pwsh.exe", StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("Ein vollständiger, geschützter Pfad zu pwsh.exe ist erforderlich.");
        SafePaths.RequireMachineInstallation(Path.GetDirectoryName(settings.PowerShellPath)!);
        SafePaths.RequireMachineInstallation(Path.Combine(AppContext.BaseDirectory, "Scripts"));
        ScriptIntegrity.Verify(Path.Combine(AppContext.BaseDirectory, "Scripts"));
        var moduleRoot = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "PowerShell", "Modules");
        if (script == "Exchange.ps1") SafePaths.RequireProtectedTree(Path.Combine(moduleRoot, "ExchangeOnlineManagement"));
        var folder=Path.Combine(Storage.Root,"Jobs",Guid.NewGuid().ToString("N"));
        SafePaths.EnsureDataDirectory(Path.GetDirectoryName(folder)!); SafePaths.EnsureDataDirectory(folder);
        var input=Path.Combine(folder,"request.json"); var output=Path.Combine(folder,"response.json");
        try
        {
            await File.WriteAllTextAsync(input,JsonSerializer.Serialize(request,Storage.Json),new UTF8Encoding(false),token);
            var start=new ProcessStartInfo(settings.PowerShellPath) { UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true };
            start.WorkingDirectory = folder;
            foreach (var name in start.Environment.Keys.Where(k => k.StartsWith("DOTNET_", StringComparison.OrdinalIgnoreCase) ||
                k.StartsWith("COMPLUS_", StringComparison.OrdinalIgnoreCase) || k.StartsWith("COR_", StringComparison.OrdinalIgnoreCase) ||
                k.StartsWith("CORECLR_", StringComparison.OrdinalIgnoreCase)).ToArray()) start.Environment.Remove(name);
            start.Environment["PSModulePath"] = Path.Combine(Path.GetDirectoryName(settings.PowerShellPath)!, "Modules") + ";" + moduleRoot;
            foreach(var arg in new[]{"-NoLogo","-NoProfile","-NonInteractive","-File",Path.Combine(AppContext.BaseDirectory,"Scripts",script),"-RequestPath",input,"-ResponsePath",output}) start.ArgumentList.Add(arg);
            using var process=Process.Start(start) ?? throw new IOException("PowerShell konnte nicht gestartet werden.");
            var stdout=process.StandardOutput.BaseStream.CopyToAsync(Stream.Null,token); var stderr=process.StandardError.BaseStream.CopyToAsync(Stream.Null,token);
            using var timeout=CancellationTokenSource.CreateLinkedTokenSource(token); timeout.CancelAfter(TimeSpan.FromMinutes(settings.TimeoutMinutes));
            try { await process.WaitForExitAsync(timeout.Token); }
            catch { if(!process.HasExited) process.Kill(true); await process.WaitForExitAsync(CancellationToken.None); throw; }
            await stdout; await stderr;
            if(process.ExitCode!=0) throw new InvalidOperationException("PowerShell-Vorgang fehlgeschlagen. Verbindung, Zertifikat und Schlüsselrechte prüfen.");
            return JsonSerializer.Deserialize<T>(await File.ReadAllTextAsync(output,token),Storage.Json) ?? throw new InvalidDataException("PowerShell lieferte kein Ergebnis.");
        }
        finally { if(Directory.Exists(folder)) { SafePaths.RequireProtectedTree(folder); Directory.Delete(folder,true); } }
    }
    public static Task<T> Exchange<T>(Settings s,string mode,object[] changes,CancellationToken ct) => Execute<T>(s,"Exchange.ps1",new { Mode=mode,s.Tenant,s.AppId,s.Thumbprint,s.ExcludedMailboxes,Changes=changes },ct);
    public static Task<CertificateInfo> Certificate(Settings s,string mode,CancellationToken ct) => Execute<CertificateInfo>(s,"Certificate.ps1",new { Mode=mode,s.Thumbprint },ct);
}
public sealed record CertificateInfo(string Thumbprint,string Subject,DateTime NotBefore,DateTime NotAfter,bool HasPrivateKey,string PublicBase64);
public sealed class Snapshot
{
    public List<Mailbox> Mailboxes { get; set; } = [];
    public List<string> Errors { get; set; } = [];
}
