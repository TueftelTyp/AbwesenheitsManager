# AbwesenheitsManager

Windows-Anwendung auf **.NET 9** für zentrale interne/externe Abwesenheitsvorlagen in Exchange Online. Enthalten sind eine WPF-Administration, ein Windows-Dienst, die gemeinsam verwendete Core-Bibliothek, die PowerShell-Anbindung und ausführbare Schutztests.

**Sichere Ausgangseinstellungen:** Dry-Run eingeschaltet, automatische Dienstläufe ausgeschaltet, Log-Stufe Warning. Es werden keine Tenant-Daten oder Kennwörter mitgeliefert. Der Dienst wird vom Installationsskript nicht gestartet.

## Hilfe in der Anwendung

Der blaue **Fragezeichen-Button rechts oben im blauen Kopfbereich** öffnet dieses Handbuch als HTML-Datei im Standardbrowser. Er ist in jedem Tab sichtbar und bleibt auch während eines laufenden Vorgangs bedienbar. Zusätzlich kann die Taste **F1** verwendet werden. Es liegt lokal unter `Help\Handbuch.html` neben der Admin-EXE und ist ohne Internet lesbar. Inhaltsverzeichnis, Browsersuche (Strg+F) und Drucken (Strg+P) stehen zur Verfügung; nur externe Quellenlinks benötigen Internet.

Nach einem Quellcode-Update die Solution neu bauen bzw. veröffentlichen und die neue Admin-EXE zusammen mit ihrem vollständigen Ausgabeordner verwenden. Eine bereits vorhandene EXE oder die früher gelieferte kompilierte .NET-10-ZIP enthält den neuen Hilfe-Button nicht automatisch.

Beim Build und Publish wird die HTML-Datei automatisch mitkopiert. Deshalb immer den vollständigen Programmordner einschließlich `Help` weitergeben. Fehlt die Datei oder kann Windows sie nicht öffnen, zeigt die Anwendung eine Fehlermeldung mit dem Dateipfad.

Für Entwickler: `README.md` bleibt die Quelle des Handbuchs. Nach Änderungen mit `pwsh -NoProfile -File .\Scripts\Build-Help.ps1` die HTML-Datei aktualisieren. `Scripts\Publish.ps1` erledigt dies automatisch vor dem Publish. Der normale Visual-Studio-Build kopiert die eingecheckte HTML-Datei und benötigt für diesen Kopierschritt kein PowerShell.

## 1. Voraussetzungen

- Unterstütztes Windows x64 mit grafischer Umgebung für die Administration; für Server Core die GUI auf einem anderen Rechner auszuführen reicht nicht, da Einstellungen und Zertifikate lokal sind. Administration deshalb auf dem Diensthost mit Desktop Experience durchführen.
- Zum Entwickeln: Visual Studio 2022 **17.14 oder neuer** mit der Workload **.NET-Desktopentwicklung** und .NET 9 SDK **9.0.3xx**. Alle Projekte verwenden `net9.0-windows`; Visual Studio 2026 ist nicht erforderlich.
- PowerShell 7.4 oder neuer und ein dazu kompatibles ExchangeOnlineManagement-Modul, mindestens 3.7.0. Eine aktuelle stabile Kombination verwenden und vor dem Einsatz prüfen. In der GUI den tatsächlichen vollständigen `pwsh.exe`-Pfad eintragen.
- Internetzugriff für NuGet beim Build und für Exchange Online beim Betrieb. SMTP-Relay nach eigener Infrastruktur.
- Lokale Administratorrechte für GUI, Maschinenzertifikat und Dienstinstallation.

In einer **erhöhten PowerShell 7** das Exchange-Modul für alle Benutzer installieren, damit LocalSystem es ebenfalls findet:

```powershell
Install-Module ExchangeOnlineManagement -Scope AllUsers -Repository PSGallery
Get-Module ExchangeOnlineManagement -ListAvailable
```

Das Programm installiert oder aktualisiert keine Module automatisch. Eine Unternehmensrichtlinie für signierte PowerShell-Skripte muss berücksichtigt werden; mitgelieferte Skripte sind nicht signiert. Die Exchange-Ausführung setzt keinen ExecutionPolicy-Bypass. Das Setup startet ausschließlich sein lokales Wartungsskript mit einem prozessbezogenen Bypass; Unternehmensrichtlinien bleiben zu beachten.

## 2. Solution öffnen, bauen und testen

Diese Fassung vollständig in einen neuen Ordner entpacken. Nicht in die alte .NET-10-Ausgabe kopieren; deren `bin`-/`obj`-Dateien und kompilierten EXE-Dateien gehören zur vorherigen Version. Die NuGet-Pakete für DPAPI und Windows-Service-Hosting sind auf 9.0.0 umgestellt.

ZIP vollständig in ein lokales Verzeichnis entpacken. `AbwesenheitsManager.sln` in Visual Studio 2022 öffnen, NuGet-Wiederherstellung zulassen und `AbwesenheitsManager.Admin` als Startprojekt auswählen. Wegen des Manifests benötigt die Administration erhöhte Rechte; gegebenenfalls Visual Studio erhöht starten oder die gebaute EXE separat als Administrator öffnen.

Im Solution-Verzeichnis:

```powershell
dotnet restore .\AbwesenheitsManager.sln
dotnet build .\AbwesenheitsManager.sln -c Release
dotnet run --project .\AbwesenheitsManager.Tests -c Release
pwsh -NoProfile -File .\Scripts\Test-Guards.ps1
```

Das Testprojekt ist ein kleiner ausführbarer Regressionstest, kein Test-Explorer-/xUnit-Projekt. Nicht mit `dotnet test` verwechseln. Ein Fehler erzeugt einen von null verschiedenen Exitcode. `global.json` verwendet .NET SDK 9.0.300 mit `latestPatch`, also das aktuelle installierte Patch des 9.0.3xx-Bands. NuGet-Versionen sind in den Projektdateien festgelegt.

| Projekt | Aufgabe |
|---|---|
| AbwesenheitsManager.Admin | WPF-Tabs für Übersicht, Microsoft 365/Zertifikate, Vorlagen, Variablen, Betrieb und SMTP |
| AbwesenheitsManager.Service | Windows-Dienst, liest Einstellungen alle 15 Sekunden |
| AbwesenheitsManager.Core | Konfiguration, DPAPI, HTML-/Variablenprüfung, SMTP und Logging |
| AbwesenheitsManager.Exchange | Prozesssteuerung, Laufplanung, Sammelbericht, PowerShell-Bridge |
| AbwesenheitsManager.Tests | 23 lokale Regressionstests |

## 3. Publish, Einrichtung und Setup

Für Entwickler: `pwsh -NoProfile -File .\Scripts\Publish.ps1` erzeugt die drei zusammengehörenden Ordner `publish\Admin`, `publish\Service` und `publish\Tray` für Windows x64 mit enthaltener .NET-Laufzeit. PowerShell 7 und ExchangeOnlineManagement werden weiterhin separat benötigt.

Der Benutzer öffnet ausschließlich **AbwesenheitsManager** (die Admin-App). Nach der Konfiguration unter Betrieb **Automatische Dienstläufe aktivieren** einschalten und **Einstellungen speichern** anklicken. Dadurch wird ein fehlender Dienst registriert, sein Windows-Starttyp auf Automatisch gesetzt und der Dienst gestartet. Die UAC-Abfrage erfolgt bereits beim Öffnen der Admin-App. Ohne Einrichtung von Tenant, Zertifikat und PowerShell ist damit noch kein erfolgreicher Exchange-Lauf garantiert.

**Deaktivieren und Speichern** schreibt zuerst den deaktivierten Zeitplan, deaktiviert den Dienststart und stoppt den Dienst. Ein laufender Dienstlauf erhält ein Abbruchsignal; bereits erfolgte Exchange-Änderungen werden nicht zurückgerollt. Bei Fehlern wird keine erfolgreiche Übernahme gemeldet. Erneutes Aktivieren und Speichern startet den Dienst wieder. Manuelle Prüfungen verwenden die eingegebenen Werte, ändern aber den gespeicherten Dienstzustand nicht; dauerhafte Änderungen mit Einstellungen speichern übernehmen.

Beim Schließen der Admin-App startet das Tray automatisch. Während eine Admin-App in derselben Windows-Sitzung geöffnet ist, bleibt das Tray-Symbol verborgen. Der Benutzer muss keine zweite EXE öffnen. Beim ersten Schließen wird auch der Benutzerautostart eingerichtet; eine später bewusst deaktivierte Einstellung wird respektiert. Der Autostart gilt für das Konto der Admin-App. Bei UAC mit anderen Anmeldedaten den Autostart für das gewünschte Konto gesondert konfigurieren.

Die vollständigen drei Ordner müssen zusammen bereitgestellt werden. Im vorgesehenen Setup-Pfad `C:\Program Files\AbwesenheitsManager` nutzt der Dienst die mitinstallierten Dateien. Benutzerbeschreibbare Quellordner (etwa Desktop oder Downloads) werden seit der Sicherheitsüberarbeitung abgewiesen. Bitte das gemeinsame Setup und eine geschützte Installation unter Programme verwenden. Eine bestehende Installation wird dabei nicht ungefragt überschrieben.

### Ein gemeinsames Setup erstellen

Die Vorlage `Setup\AbwesenheitsManager.iss` bündelt alle Komponenten, einen einzigen Startmenüeintrag und einen Windows-Deinstallationseintrag. Voraussetzung auf dem Build-Rechner: Inno Setup 6 und die bisherigen Build-Werkzeuge.

```powershell
.\Scripts\Build-Setup.ps1
```

Ergebnis nach erfolgreichem Build: `setup-output\AbwesenheitsManager-Setup.exe`. Der Endanwender benötigt die Solution und Build-Werkzeuge nicht. Die Setup-Vorlage wurde hier noch nicht kompiliert oder auf einem Zielsystem abgenommen.

Vor Update oder Deinstallation die Admin-App schließen. Das Setup beendet das Tray und entfernt die bisherige Dienstregistrierung sowie eine ältere ServiceHost-Kopie. Beim Update bleiben Einstellungen und Logs erhalten; danach die Admin-App öffnen und die gewünschte Automatisierung erneut speichern.

Die Deinstallation entfernt Dienst, Tray, installierte Programmdateien, Startmenüeintrag, Benutzerautostarts in lokalen Profilen sowie ProgramData-Einstellungen, Statusdatei und Logs. Zertifikate, Entra-App, Exchange-Konfiguration, PowerShell und Exchange-Module werden nicht gelöscht: Diese Ressourcen können auch außerhalb dieses Programms verwendet werden. Fehler bei der Bereinigung werden protokolliert und müssen vor Abschluss behoben werden. Details zur Setup-Technik: [Inno Setup – Ereignisfunktionen](https://jrsoftware.org/ishelp/topic_scriptevents.htm).

## 4. Entra-App und Exchange-Rechte

1. In Microsoft Entra eine **Single-Tenant-App-Registrierung** anlegen. Application (Client) ID notieren. Für den Tenant in der GUI die ursprüngliche `firma.onmicrosoft.com`-Domäne verwenden, nicht die Directory-ID.
2. Unter API-Berechtigungen → **Office 365 Exchange Online** → **Application permissions** → `Exchange.ManageAsApp` hinzufügen und mandantenweite Administratorzustimmung erteilen. Ein Client Secret wird nicht benötigt.
3. In der erhöht gestarteten GUI den PowerShell-Pfad setzen, unter **Microsoft 365** ein Zertifikat erstellen und den öffentlichen Teil als `.cer` exportieren. Erzeugt wird ein ein Jahr gültiges, selbstsigniertes RSA-2048/SHA-256-Zertifikat mit CSP-Provider; der private Schlüssel ist nicht exportierbar und liegt in `LocalMachine\My`.
4. In der Entra-App unter **Certificates & secrets → Certificates** die `.cer` hochladen. Der private Schlüssel verbleibt auf dem Server. Tenant, App-ID und Thumbprint in der GUI speichern.
5. Zusätzlich zur API-Berechtigung benötigt der Service Principal **Exchange-Verwaltungsrollen**. Für Produktion eine eigene eingeschränkte Exchange-Rollengruppe verwenden. Keine breite Entra-Rolle Exchange Administrator als Standard vergeben. Der Ablauf einschließlich Pilot- und Negativtest steht in EXCHANGE-RECHTE.md.
6. Für eine eingeschränkte Installation die in Microsofts App-only-Dokumentation beschriebene benutzerdefinierte Exchange-Rollengruppe für Anwendungen verwenden. Benötigt werden Lesezugriff auf `Get-EXOMailbox` und `Get-MailboxAutoReplyConfiguration` sowie `Set-MailboxAutoReplyConfiguration` mit den Parametern `Identity`, `InternalMessage`, `ExternalMessage`. Die konkrete vorhandene Rollenkombination und den Empfängerbereich im eigenen Tenant prüfen. Keine reine Graph-`Mail.ReadWrite`-Berechtigung und keine ApplicationAccessPolicy als Ersatz für diese PowerShell-Rollen verwenden.

Für den eingeschränkten Weg wird der Service Principal gegebenenfalls in Exchange registriert. **ObjectId ist die Objekt-ID der Enterprise Application, nicht die Objekt-ID der App-Registrierung**:

```powershell
# Einmalige administrative Einrichtung, interaktiv mit berechtigtem Administratorkonto:
Connect-ExchangeOnline
New-ServicePrincipal -AppId '<Application-Client-ID>' -ObjectId '<Enterprise-Application-Object-ID>' -DisplayName 'AbwesenheitsManager'
Get-ServicePrincipal | Where-Object AppId -eq '<Application-Client-ID>'
# Anschließend eine geprüfte benutzerdefinierte Rollengruppe gemäß Microsoft-Dokumentation
# zuweisen. Rollennamen/-umfang hängen von der gewählten Tenant-RBAC-Konfiguration ab.
Disconnect-ExchangeOnline -Confirm:$false
```

Die Anwendung erstellt keine Entra-Apps und vergibt keine Cloud-Berechtigungen. Nach Rollenänderungen Replikationszeit einplanen. Der Verbindungstest prüft Anmeldung, Lesen und Verfügbarkeit der Cmdlets; er beweist keine Schreibberechtigung für alle Empfänger. Diese erst mit einem kontrollierten Pilotpostfach prüfen.

Die Verbindung lädt das Zertifikat ausdrücklich aus `Cert:\LocalMachine\My` und übergibt es als **`-Certificate`-Objekt**. `-CertificateThumbprint` allein würde den Benutzerzertifikatsspeicher erwarten. Die Zertifikatsprüfung führt eine lokale Testsignatur aus, um den Zugriff auf den privaten Schlüssel zu prüfen. Bei importierten Zertifikaten über `certlm.msc` → persönliche Zertifikate → private Schlüssel verwalten sicherstellen, dass SYSTEM lesen darf. Die GUI-Prüfung läuft als Administrator; auch den ersten Dienst-Dry-Run auswerten.

## 5. Vorlagen- und Variablenlogik

Es werden Benutzer- und freigegebene Postfächer berücksichtigt. Ausschlüsse beziehen sich exakt, ohne Beachtung der Großschreibung, auf die **primäre SMTP-Adresse**. Aliase, Wildcards, Raum-/Geräte-/Gruppenpostfächer gehören nicht zum Umfang.

- `Enabled`, `Scheduled` und unbekannte Zustände werden übersprungen – auch ein abgelaufener Zeitplan mit weiterhin `Scheduled` wird nicht angefasst.
- Nur bei `Disabled` werden interne und externe Nachricht separat geprüft.
- Die festen HTML-/Textteile müssen mit der entsprechenden Vorlage übereinstimmen. Lediglich definierte Variablenbereiche dürfen abweichen. Regex wird auf den gesamten HTML-dekodierten Variablenwert angewendet, mit 250-ms-Zeitlimit. Ein Timeout führt zu einem Fehler für dieses Postfach, nicht zu einer Korrektur.
- Namen, Platzhalter und Beschreibungen sind frei editierbar. Leere Regex bedeutet keine Zusatzprüfung. Platzhalter sind eindeutige, nicht überlappende Zeichenfolgen, ausschließlich in HTML-Textknoten; keine Platzhalter in Attributen, Links oder Tag-Namen. Benachbarte Platzhalter benötigen festen Trenntext.
- Mehrfach verwendete identische Platzhalter müssen identische Werte haben. Ungefüllte Platzhalter in der Standardvorlage werden trotz Regex zugelassen, damit eine frisch gesetzte Vorlage nicht bei jedem Lauf erneut korrigiert wird.
- Variable Inhalte sind **Text**, keine zusätzlichen HTML-Tags. Die Anwendung normalisiert Entities, Attributreihenfolge und die äußeren html/body-Hüllen. Kommentare und head-Inhalt werden ignoriert. Sonstige Formatierung, Attribute und Textabstände sind Teil der festen Vorlage. Outlook kann HTML umformatieren; deshalb Ergebnisse im Dry-Run mit realen Postfächern prüfen und Vorlagen gegebenenfalls daran anpassen.
- Ist eine Seite nicht konform, wird **diese ganze Seite durch ihre Standardvorlage ersetzt**, einschließlich der dortigen Platzhalter. Bereits ausgefüllte Variablen dieser abweichenden Seite werden nicht heuristisch gerettet. Eine korrekte andere Seite bleibt unverändert. Die Anwendung befüllt Variablen nicht aus Mitarbeiterdaten.
- Leere deaktivierte Nachrichten werden durch die Standardvorlagen initialisiert.

Die deutsche Urlaubsvorlage aus dem verfügbaren bisherigen Entwurf ist für intern und extern vorbelegt:

> Vielen Dank für Ihre Nachricht.
>
> Ich befinde mich derzeit im Urlaub und bin bis einschließlich **[Datum]** nicht erreichbar. Ihre E-Mail wird nicht weitergeleitet und nach meiner Rückkehr schnellstmöglich bearbeitet.
>
> In dringenden Fällen wenden Sie sich bitte an **[Vertretung]** unter **[E-Mail-Adresse]** oder **[Telefonnummer]**.
>
> Vielen Dank für Ihr Verständnis.
>
> Mit freundlichen Grüßen

Die Vorlagen können unabhängig voneinander bearbeitet werden. Beispieldateien liegen zusätzlich unter `Examples`.

### Grenze bei gleichzeitigen Änderungen

Vor jedem `Set-MailboxAutoReplyConfiguration` werden Status und beide Originaltexte erneut gelesen. Bei Änderungen wird das Postfach übersprungen. Der Schreibaufruf setzt **niemals** AutoReplyState, StartTime, EndTime oder ExternalAudience.

Exchange bietet diesem Cmdlet keine atomare Compare-and-Set-Bedingung. Eine Benutzeränderung genau zwischen letzter Abfrage und Schreibaufruf kann deshalb nicht vollständig ausgeschlossen werden. Die absolute Forderung „auch bei jeder gleichzeitigen Änderung niemals ein inzwischen aktives Postfach verändern“ ist über diese API technisch nicht garantierbar. Für eine solche Garantie ist ausschließlich **Dry-Run** geeignet. Produktivläufe in einem geeigneten Wartungsfenster durchführen. Eine Dateisperre verhindert überlappende Läufe von GUI und Dienst auf demselben Host; keine Sperre über mehrere Server hinweg. Nur einen Diensthost betreiben.

## 6. Erste Inbetriebnahme

1. Publish-Dateien und Voraussetzungen installieren. GUI als Administrator starten.
2. Tenant, App-ID, Zertifikat und PowerShell-Pfad konfigurieren, Zertifikat in Entra hochladen und Rollen vergeben.
3. **Zertifikat prüfen** und **Exchange-Verbindung testen** ausführen.
4. Interne/externe HTML-Vorlagen, Variablen und Ausschlüsse konfigurieren. Unter Vorlagen Beispieltexte lokal prüfen.
5. Unter SMTP eigenes Relay, Absender und Empfänger setzen; Testnachricht senden. Betreff, Einleitung sowie Meldungen bei Warnungen/Fehlern sind konfigurierbar.
6. **Dry-Run starten**. Unter Übersicht die geplanten Änderungen und Fehler prüfen. Dies ist eine tatsächliche Exchange-Leseprüfung, kein Demo-Lauf.
7. Zunächst in einem Testtenant oder mit passend eingeschränkter Exchange-RBAC-Empfängersicht testen. Die Ausschlussliste ist keine serverseitige Sicherheitsgrenze.
8. Nach Prüfung für produktive Korrekturen Dry-Run ausschalten, Intervall setzen, automatische Dienstläufe aktivieren und speichern. Dienst starten. Der erste fällige Lauf erfolgt binnen etwa 15 Sekunden; existiert eine letzte Zusammenfassung, wird deren Abschlusszeit als Ausgangspunkt verwendet.

„Dry-Run starten“ erzwingt den Testmodus für diesen Lauf. „Lauf gemäß Einstellungen“ berücksichtigt das gespeicherte Dry-Run-Feld. Beide speichern vorher die aktuellen GUI-Einstellungen. Ein manueller Lauf kann erfolgen, auch wenn automatische Läufe ausgeschaltet sind. Eine Serviceinstanz merkt sich ihren letzten eigenen Lauf bis zum Neustart; GUI-Läufe verschieben den bereits laufenden Dienstzeitplan nicht.

Zeitlimit gilt **je PowerShell-Prozess**, nicht für den gesamten Lauf. Bei Timeout wird der Prozessbaum beendet. Bereits vorgenommene Änderungen werden nicht zurückgerollt, und die Zusammenfassung kann dann unvollständig sein; anschließend Dry-Run ausführen.

## 7. SMTP, Geheimnisse und Protokolle

- SMTP verwendet STARTTLS (z. B. 587) mit Benutzer/Passwort oder ein internes Relay ohne Anmeldung. Kein implizites TLS auf Port 465, kein SMTP-OAuth. Für Exchange-Online-SMTP ggf. ein separates geeignetes Relay verwenden, statt Basic-Auth-Verfügbarkeit vorauszusetzen.
- Einträge für Benutzername ohne STARTTLS werden beim Speichern abgewiesen. Zertifikatsprüfung bei TLS wird nicht abgeschaltet.
- Das Passwort wird per **Windows DPAPI LocalMachine** verschlüsselt. Die GUI zeigt den gespeicherten Wert nie an; leeres Passwortfeld behält ihn bei, eine separate Checkbox löscht ihn. Das Passwort steht nicht in PowerShell-Argumenten oder -Jobdateien.
- DPAPI LocalMachine ist **keine Benutzerzugriffsgrenze**: jeder lokale Prozess mit Zugriff auf den Ciphertext könnte ihn auf diesem Host entschlüsseln. Deshalb schützt die Anwendung das Datenverzeichnis mit ACLs für Administratoren und SYSTEM. Keine unberechtigten Benutzer zu lokalen Administratoren machen.
- Daten: `%ProgramData%\AbwesenheitsManager\settings.json`, `last-run.json`, `Logs\yyyy-MM.log`. Kurzlebige Jobs im Unterordner `Jobs` enthalten Mailboxdaten und werden nach Abschluss entfernt; bei Prozess-/Systemabsturz können Reste verbleiben. Geschützte Backups und Aufbewahrungsfristen administrativ verwalten. Logrotation erfolgt monatlich, keine automatische Löschung.
- Standard `Warning` schreibt Warnungen und Fehler. `Information` ergänzt Laufabschluss, `Debug` den ausführlichen Bericht, `Off` unterdrückt Logdateieinträge. Letzte Zusammenfassung und gewählte SMTP-Meldungen werden unabhängig davon erstellt.
- Zertifikatsablauf, Vorlagenabweichungen und zwischenzeitliche Änderungen sind Warnungen; Zertifikats-/Verbindungs-/Mailbox-/Prozessfehler sind Fehler. Bei gewählten Ereignissen entsteht höchstens **eine Sammelmail pro Lauf**, auch im Dry-Run. Wiederkehrende Fehler können folglich je Intervall erneut gemeldet werden. SMTP-Fehler stehen im lokalen Bericht/Log und können nicht über denselben fehlgeschlagenen Kanal gemeldet werden.
- Lokale Berichte können Postfachadressen enthalten; externe Ausnahme-Freitexte werden durch feste Fehlerkategorien ersetzt. SMTP-Sammelmeldungen enthalten nur Zeiten und Zähler. Bereits vorhandene ältere Logs werden nicht nachträglich bereinigt.
- Konfiguration ist maschinengebunden. Auf einem anderen Server SMTP-Passwort neu eingeben und ein neues Zertifikat erstellen/registrieren. Das Programm exportiert ausschließlich den öffentlichen Zertifikatteil.

## 8. Zertifikat erneuern

Vor Ablauf auf demselben Host ein neues Zertifikat über die GUI erzeugen, öffentlichen Teil exportieren und zusätzlich in derselben Entra-App registrieren. Neuen Thumbprint speichern, Verbindung und Dienst-Dry-Run prüfen. Erst nach erfolgreichem Übergang altes Zertifikat aus Entra und anschließend aus dem Maschinenstore entfernen. Keine automatische Löschung oder Cloud-Registrierung durch die Anwendung.

## 9. Prüfstand und bekannte Grenzen

Siehe `VALIDATION.md` für den Prüfstand dieser .NET-9-Fassung. Der Sicherheitsstand vom 23.10.2026 wurde erfolgreich gebaut; Details und offene Integrationstests stehen in SECURITY-REVIEW.md. Kein produktiver Tenant, SMTP-Server oder Dienst wurde für die Erstellung eingerichtet. Ein erfolgreicher Build ersetzt den Pilotlauf nicht. Die Anwendung bietet kein Remote-Administrationsprotokoll, keine Graph-Synchronisation und keinen automatischen Text-Rollback.

## 10. Offizielle Referenzen

- [App-only-Authentifizierung, Zertifikate und Rollen](https://learn.microsoft.com/en-us/powershell/exchange/app-only-auth-powershell-v2?view=exchange-ps)
- [Set-MailboxAutoReplyConfiguration und Parameter](https://learn.microsoft.com/en-us/powershell/module/exchangepowershell/set-mailboxautoreplyconfiguration?view=exchange-ps)
- [.NET unter Windows und passende Visual-Studio-Version](https://learn.microsoft.com/dotnet/core/install/windows)
- [.NET SDKs für Visual Studio / LTS](https://dotnet.microsoft.com/en-us/download/visual-studio-sdks)

Diese Quellen wurden bei der Erstellung am 30.09.2026 geprüft; Microsoft kann Modulanforderungen und Tenant-Verfahren ändern.


## Tray-Symbol und Benutzerautostart

Das neue Projekt `AbwesenheitsManager.Tray` verwendet Windows Forms und .NET 9. Es läuft im angemeldeten Benutzerkonto unabhängig vom Windows-Dienst `AbwesenheitsManager`. **Beenden schließt ausschließlich die Tray-App**. Es gibt im Tray keine Funktion zum Stoppen oder Ändern des Dienstes.

Nach `Scripts\Publish.ps1` die Ordner `Admin`, `Service` und `Tray` gemeinsam unter einem festen Installationsordner ablegen (beispielsweise unter Programme, nur für Administratoren beschreibbar). Admin und Tray finden einander in diesen benachbarten Ordnern oder im selben Verzeichnis. Nicht nur einzelne EXE-Dateien kopieren.

Im Tab **Betrieb → Tray-Anwendung** den Schalter **Tray-Symbol bei der Anmeldung dieses Kontos starten** setzen und **Tray-Autostart übernehmen** anklicken. Die Einstellung wirkt sofort, unabhängig von „Speichern“. Sie schreibt einen korrekt in Anführungszeichen gesetzten absoluten EXE-Pfad nach `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`, Wert `AbwesenheitsManager.Tray`. Nach dem Verschieben des Installationsordners erneut übernehmen. Deaktivieren entfernt ausschließlich diesen Wert. Windows kann Autostarts zusätzlich im Task-Manager deaktivieren; die GUI zeigt die Registrierung an.

Der Schalter gilt für das ausdrücklich angezeigte Konto der erhöhten Admin-App. Bei UAC mit anderen Administrator-Zugangsdaten im gewünschten normalen Benutzerkonto ohne Erhöhung ausführen:

```powershell
.\Scripts\Set-TrayAutostart.ps1 -TrayPath 'C:\Program Files\AbwesenheitsManager\Tray\AbwesenheitsManager.Tray.exe'
# Ausschalten:
.\Scripts\Set-TrayAutostart.ps1 -Disable
```

Alternativ unterstützt die Tray-EXE `--enable-autostart` und `--disable-autostart`. Beim Schließen der Admin-App startet das Tray automatisch; danach startet es bei jeder Anmeldung, sofern der Autostart aktiviert bleibt. Beim ersten Schließen der Admin-App wird der Autostart eingerichtet, sofern noch keine Benutzerentscheidung gespeichert wurde. Pro Sitzung wird nur eine Tray-Instanz zugelassen. Windows kann das Symbol im Überlaufmenü neben der Uhr ablegen.

Ein Doppelklick oder **Admin-Oberfläche öffnen** öffnet die Admin-GUI mit ihrer bisherigen UAC-Abfrage. **Jetzt prüfen** öffnet die Übersicht mit `--check`: Dort ausdrücklich **Dry-Run starten** oder **Lauf gemäß Einstellungen** auswählen. Der bestehende Runner einschließlich Lauf-Sperre, SMTP, Zertifikatsprüfung und Exchange-Schutzlogik wird weiterverwendet. Ein Klick im Tray führt noch keine Exchange-Änderung aus. Eine abgelehnte UAC-Abfrage wird als Meldung angezeigt.

Das Kontextmenü enthält Dienststatus, letzte Prüfung, nächste Prüfung, Öffnen der Admin-Oberfläche, Jetzt prüfen, Dienststatus aktualisieren und Beenden. Status und Tooltip werden alle 15 Sekunden sowie beim Öffnen des Menüs aktualisiert:

- Grün: Dienst läuft, keine gemeldeten Fehler oder Warnungen.
- Gelb: Dienst läuft, letzter Lauf enthält Warnungen.
- Rot: Dienst läuft nicht oder letzter Lauf/Dienst meldet Fehler.
- Grau: Dienst bewusst deaktiviert (Inaktiv) oder Status unbekannt/veraltet; der Text unterscheidet beide Fälle.

Das bereitgestellte Programmicon liegt unverändert unter `Assets/icon.ico` und `Assets/icon.png`. Admin-, Service- und Tray-Programmdateien verwenden das ICO. Das Admin-Fenster zeigt das Icon in Titelleiste und Kopfbereich; der sichtbare Programmname lautet **AbwesenheitsManager**. Das Tray verwendet dasselbe Icon mit einer kleinen grünen, gelben, roten oder grauen Statusmarkierung. Technische Projekt- und EXE-Namen bleiben zur Kompatibilität mit Dienstinstallation und Autostart erhalten.

Die geschützte `last-run.json` bleibt die Quelle der Laufzusammenfassung. Der Dienst veröffentlicht daraus ausschließlich Zeitpunkte, Warnungs-/Fehleranzahlen und Zeitplanstatus nach `%ProgramData%\AbwesenheitsManager.Status\status.json`. Dieser separate Ordner erlaubt normalen Benutzern nur Lesen; Schreiben bleibt Administratoren und LocalSystem vorbehalten. SMTP-Daten, Postfächer und Fehlermeldungstexte werden nicht veröffentlicht. Die vorhandenen Berechtigungen der eigentlichen Konfiguration bleiben erhalten. Die nächste Prüfung stammt aus dem tatsächlich im Dienst verwendeten Zeitplan; bei deaktiviertem Zeitplan wird dies ausdrücklich angezeigt. Während Dienstläufen erneuert ein Statussignal die Anzeige. Bei gestopptem/nicht erreichbarem Dienst wird kein nächster Termin zugesichert.

Nach einem Setup-Update die Admin-App öffnen und die gewünschte Dienstaktivierung speichern. Deinstallation erfolgt über den gemeinsamen Windows-Programmeintrag; siehe Abschnitt 3.





## Sicherheitsüberarbeitung vom 23.10.2026

Der Quellcode wurde bei SMTP, Datei-/Verzeichnisberechtigungen, PowerShell-Ausführung, Tray-Start und Deinstallation gehärtet. **Produktiv nur aus einer geschützten Installation unter Programme starten.** Auch PowerShell und ExchangeOnlineManagement müssen maschinenweit und nicht benutzerbeschreibbar installiert sein. Ein WindowsApps-Alias im Benutzerprofil ist für privilegierte Aufrufe nicht zulässig.

Bei unsicheren vorhandenen Datenordnern bricht die Anwendung ab, statt fremde Dateien automatisch zu übernehmen. Bestehende Installationen daher vor dem Upgrade sichern und ihre Rechte kontrolliert prüfen. Eigentümer und Schreibzugriff müssen SYSTEM, Administratoren oder TrustedInstaller entsprechen.

Der Tray-Start erfolgt über den vorhandenen Explorer-Desktop ohne Übernahme des Admin-Tokens. Die Standard-Autostartregistrierung erfolgt im tatsächlichen Tray-Benutzerkonto. Der manuelle Autostart-Schalter der erhöhten Admin-App gilt weiterhin für das dort angezeigte Konto.

Build: 0 Fehler/Warnungen. 56 C#-Tests und 15 PowerShell-Schutztests bestanden. Windows-Installations-/Deinstallationstests und der vollständige Paket-Schwachstellenscan sind noch offen. Vollständiger Befundbericht: `SECURITY-REVIEW.md`.

## Zusätzliche Sicherheitsprüfungen

Private ProgramData-Dateien einschließlich bestehender Unterordner dürfen ausschließlich SYSTEM und Administratoren Zugriff erlauben. Explizite Benutzer-Leserechte werden ebenso verweigert wie Schreibrechte. Der öffentliche Tray-Status bleibt getrennt. Bei einer Ablehnung vorhandene Rechte als Administrator gezielt prüfen; das Programm repariert fremde oder zu breite Rechte nicht stillschweigend.

Der private Zertifikatsschlüssel wird vor Prüfung/Benutzung auf Besitzer, Zugriffsrechte und verknüpfte Pfade geprüft. Unterstützt werden maschinenweite RSA-CSP-Software-Schlüssel und Microsoft Software Key Storage Provider (CNG). Andere Provider, Benutzer-Schlüssel und Hardware-Schlüssel werden sicherheitshalber abgewiesen. In certlm.msc unter Persönlich/Zertifikate → Alle Aufgaben → Private Schlüssel verwalten dürfen nur SYSTEM und Administratoren Zugriff erhalten. Auch der Besitzer muss vertrauenswürdig sein. Importierte Schlüssel werden nicht automatisch umgeschrieben. Neu angelegte Zertifikate bleiben bei fehlgeschlagener anschließender Rechteprüfung im Store; vor erneutem Erstellen prüfen.

Die vier ausgelieferten Laufzeitskripte werden vor jedem PowerShell-Start per SHA-256 mit in der Exchange-Assembly eingebetteten Referenzen verglichen. Nach Skriptänderungen müssen Anwendung und Skripte gemeinsam neu gebaut werden. Das ersetzt keine Signatur des Installationspakets und schützt nicht gegen einen bereits privilegierten Angreifer, der auch die Assembly ersetzen kann.

Vorlagen: maximal 1.048.576 Zeichen pro HTML-Nachricht, Verschachtelung maximal 128, maximal 64 Variablen, 128 Zeichen je Name/Platzhalter und 2048 Zeichen je Validierungsregex. Platzhalter werden literal gezählt; die verbleibenden Laufzeit-Regex-Ausführungen besitzen ein Zeitlimit von 250 ms. Überschreitungen führen zum Abbruch, nicht zur Korrektur eines Postfachs.

Der Dienst läuft weiterhin als LocalSystem. Ein separates Dienstkonto ist eine offene Architekturänderung mit Auswirkungen auf Zertifikatsrechte, DPAPI, Datenverzeichnis und Installation. Deshalb ist dieser Stand noch keine Abnahme einer Least-Privilege-Dienstidentität. Tenant-Rechte, Installation/Upgrade/Deinstallation und echte CSP-/CNG-Schlüssel müssen auf einem Testsystem abgenommen werden.
